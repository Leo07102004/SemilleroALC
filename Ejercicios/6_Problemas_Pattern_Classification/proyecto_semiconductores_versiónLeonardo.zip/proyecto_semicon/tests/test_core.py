"""
Pruebas unitarias (sección 8.2 del documento base).
Ejecutar con: python3 tests/test_core.py
"""
import sys
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from stable_linalg import logdet_and_quadform, condition_number, safe_cholesky, CholeskyFailure
from gaussian_classifier import GaussianClassClassifier
from shrinkage import balanced_accuracy


def test_logdet_quadform_matches_explicit_inverse():
    rng = np.random.default_rng(0)
    A = rng.normal(size=(6, 6))
    Sigma = A @ A.T + 3 * np.eye(6)
    deltas = rng.normal(size=(15, 6))

    logdet, quad = logdet_and_quadform(Sigma, deltas)
    logdet_ref = np.log(np.linalg.det(Sigma))
    inv = np.linalg.inv(Sigma)
    quad_ref = np.einsum('ij,jk,ik->i', deltas, inv, deltas)

    assert abs(logdet - logdet_ref) < 1e-8
    assert np.max(np.abs(quad - quad_ref)) < 1e-8


def test_cholesky_fails_on_rank_deficient_matrix():
    rng = np.random.default_rng(1)
    v = rng.normal(size=5)
    Sigma_rank1 = np.outer(v, v)  # rango 1, no SPD para d=5
    try:
        safe_cholesky(Sigma_rank1)
        assert False, "debería haber fallado"
    except CholeskyFailure:
        pass


def test_condition_number_identity_is_one():
    I = np.eye(4)
    assert abs(condition_number(I) - 1.0) < 1e-10


def test_shrinkage_lambda_one_equals_diagonal():
    """Con lambda=1, la covarianza contraída debe coincidir con la diagonal pura."""
    rng = np.random.default_rng(2)
    X = rng.normal(size=(200, 5))
    y = (rng.random(200) < 0.3).astype(int)

    clf_shrink = GaussianClassClassifier(cov_type="shrinkage", shrinkage_lambda=1.0).fit(X, y)
    clf_diag = GaussianClassClassifier(cov_type="diagonal").fit(X, y)

    for c in clf_shrink.classes_:
        assert np.allclose(clf_shrink.Sigma_[c], clf_diag.Sigma_[c], atol=1e-10)


def test_full_covariance_singular_when_n_class_less_than_d():
    """Con menos observaciones por clase que dimensiones, la covarianza
    completa debe ser detectada como numéricamente singular (fallo en el
    primer intento de Cholesky, sin jitter)."""
    rng = np.random.default_rng(3)
    d = 20
    n_per_class = 8  # < d
    X0 = rng.normal(size=(n_per_class, d))
    X1 = rng.normal(size=(n_per_class, d)) + 1.0
    X = np.vstack([X0, X1])
    y = np.array([0] * n_per_class + [1] * n_per_class)

    clf = GaussianClassClassifier(cov_type="full").fit(X, y)
    _ = clf.predict(X)  # fuerza el cálculo del discriminante
    assert clf.cholesky_failed_[0] is True
    assert clf.cholesky_failed_[1] is True


def test_gaussian_classifier_separates_well_separated_classes():
    """Con clases bien separadas y n >> d, el clasificador (cualquier
    familia) debe lograr una clasificación casi perfecta."""
    rng = np.random.default_rng(4)
    d = 3
    X0 = rng.normal(loc=0, scale=1, size=(300, d))
    X1 = rng.normal(loc=8, scale=1, size=(300, d))
    X = np.vstack([X0, X1])
    y = np.array([0] * 300 + [1] * 300)

    clf = GaussianClassClassifier(cov_type="full").fit(X, y)
    preds = clf.predict(X)
    acc = np.mean(preds == y)
    assert acc > 0.99


def run_all():
    tests = [v for k, v in globals().items() if k.startswith("test_")]
    passed = 0
    for t in tests:
        try:
            t()
            print(f"OK   {t.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"FAIL {t.__name__}: {e}")
    print(f"\n{passed}/{len(tests)} pruebas pasaron")


if __name__ == "__main__":
    run_all()
