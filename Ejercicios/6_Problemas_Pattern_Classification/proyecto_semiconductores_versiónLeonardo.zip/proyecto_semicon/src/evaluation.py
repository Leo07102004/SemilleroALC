"""
Sección 3.5 del documento base: evaluación y productos del Problema 2.
"""
import numpy as np


def confusion_matrix(y_true, y_pred):
    tp = int(np.sum((y_pred == 1) & (y_true == 1)))
    fn = int(np.sum((y_pred == 0) & (y_true == 1)))
    tn = int(np.sum((y_pred == 0) & (y_true == 0)))
    fp = int(np.sum((y_pred == 1) & (y_true == 0)))
    return dict(tp=tp, fn=fn, tn=tn, fp=fp)


def sensitivity_specificity(cm):
    sens = cm["tp"] / (cm["tp"] + cm["fn"]) if (cm["tp"] + cm["fn"]) > 0 else np.nan
    spec = cm["tn"] / (cm["tn"] + cm["fp"]) if (cm["tn"] + cm["fp"]) > 0 else np.nan
    return sens, spec


def precision_recall_curve(y_true, proba_fail, n_thresholds: int = 50):
    """Curva precisión-recall variando el umbral sobre P(fallo | x).
    Devuelve arrays (recall, precision, thresholds)."""
    thresholds = np.linspace(0, 1, n_thresholds)
    precisions, recalls = [], []
    for t in thresholds:
        pred = (proba_fail >= t).astype(int)
        cm = confusion_matrix(y_true, pred)
        prec = cm["tp"] / (cm["tp"] + cm["fp"]) if (cm["tp"] + cm["fp"]) > 0 else 1.0
        rec = cm["tp"] / (cm["tp"] + cm["fn"]) if (cm["tp"] + cm["fn"]) > 0 else 0.0
        precisions.append(prec)
        recalls.append(rec)
    return np.array(recalls), np.array(precisions), thresholds


def average_precision(recalls, precisions):
    """Área bajo la curva PR por integración trapezoidal (recall ordenado)."""
    order = np.argsort(recalls)
    r, p = recalls[order], precisions[order]
    trapz = getattr(np, "trapezoid", None) or np.trapz
    return float(trapz(p, r))


def cost_sensitive_threshold(y_true, proba_fail, cost_fn: float, cost_fp: float,
                              n_thresholds: int = 200):
    """Escoge el umbral que MINIMIZA el costo esperado total:
       costo = cost_fn * FN + cost_fp * FP
    (sección 3.3, punto 7: decisión sensible al costo, p.ej. cuando omitir
    un fallo real es mucho más costoso que una falsa alarma)."""
    thresholds = np.linspace(0.001, 0.999, n_thresholds)
    best_t, best_cost = 0.5, np.inf
    costs = []
    for t in thresholds:
        pred = (proba_fail >= t).astype(int)
        cm = confusion_matrix(y_true, pred)
        cost = cost_fn * cm["fn"] + cost_fp * cm["fp"]
        costs.append(cost)
        if cost < best_cost:
            best_cost, best_t = cost, t
    return best_t, best_cost, thresholds, np.array(costs)
