"""
Ranking univariado de variables mediante estadístico t de Welch entre
clase 'fallo' y clase 'pasa', calculado SOLO con el conjunto de
entrenamiento. Se usa para (a) fijar un subconjunto moderado de variables
en la comparación principal de familias de covarianza, y (b) construir el
experimento n vs. d de la sección 3.3, punto 6.
"""
import numpy as np
from scipy import stats


def rank_features_ttest(X: np.ndarray, y: np.ndarray) -> np.ndarray:
    """Devuelve los índices de columnas ordenados por |t-estadístico|
    descendente (Welch t-test, varianzas desiguales)."""
    x1 = X[y == 1]
    x0 = X[y == 0]
    t_stat, _ = stats.ttest_ind(x1, x0, equal_var=False, nan_policy="omit")
    t_stat = np.nan_to_num(t_stat, nan=0.0)
    order = np.argsort(-np.abs(t_stat))
    return order, t_stat


if __name__ == "__main__":
    from preprocess import run

    out = run(save=False)
    Xtr, ytr = out["X_train"].values, out["y_train"].values
    order, t_stat = rank_features_ttest(Xtr, ytr)
    cols = out["X_train"].columns.to_numpy()
    print("Top 15 variables por |t-estadístico| (train):")
    for i in order[:15]:
        print(f"  {cols[i]:6s}  t={t_stat[i]:7.3f}")
