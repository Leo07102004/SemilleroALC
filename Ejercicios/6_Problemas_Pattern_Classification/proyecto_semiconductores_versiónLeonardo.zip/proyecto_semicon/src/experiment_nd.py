"""
Paso 6 de la ruta computacional: repetir el ajuste para distintos números
de observaciones (n) y subconjuntos de variables (d, elegidas por ranking
t-test sobre train), construyendo una superficie de error E(n,d) y
registrando, para CADA celda, el número de condición y si Cholesky falló
en el primer intento (sin jitter) — el objeto de estudio central de un
semillero de álgebra lineal computacional: cómo se degrada la solución de
un sistema lineal (aquí, Sigma^-1) al acercarse o cruzar el régimen n < d.
"""
import numpy as np
from gaussian_classifier import GaussianClassClassifier
from feature_ranking import rank_features_ttest
from shrinkage import balanced_accuracy


def error_surface(X_train, y_train, X_val, y_val, ns, ds, cov_type="full",
                   shrinkage_lambda=0.3, seed=0):
    """Para cada combinación (n, d):
      - se toma una submuestra estratificada de tamaño n del train
        (preservando proporción de fallos)
      - se seleccionan las d variables de mayor |t-estadístico| (ranking
        recalculado en la submuestra, para no filtrar información global)
      - se ajusta el clasificador y se evalúa balanced accuracy en validación

    Devuelve un DataFrame largo con columnas: n, d, balanced_acc, sens,
    spec, cond_clase1, cholesky_failed.
    """
    import pandas as pd
    rng = np.random.default_rng(seed)
    idx_pos = np.where(y_train == 1)[0]
    idx_neg = np.where(y_train == 0)[0]
    pos_frac = len(idx_pos) / len(y_train)

    rows = []
    for n in ns:
        n_pos = max(2, int(round(n * pos_frac)))
        n_neg = n - n_pos
        if n_pos > len(idx_pos) or n_neg > len(idx_neg):
            continue
        sel_pos = rng.choice(idx_pos, size=n_pos, replace=False)
        sel_neg = rng.choice(idx_neg, size=n_neg, replace=False)
        sel = np.concatenate([sel_pos, sel_neg])
        Xs, ys = X_train[sel], y_train[sel]

        order, _ = rank_features_ttest(Xs, ys)

        for d in ds:
            if d > Xs.shape[1]:
                continue
            cols = order[:d]
            Xs_d = Xs[:, cols]
            Xval_d = X_val[:, cols]

            try:
                clf = GaussianClassClassifier(cov_type=cov_type,
                                               shrinkage_lambda=shrinkage_lambda).fit(Xs_d, ys)
                preds = clf.predict(Xval_d)
                bal_acc, sens, spec = balanced_accuracy(y_val, preds)
                cond1 = clf.condition_numbers_[1]
                chol_failed = clf.cholesky_failed_[1]
            except Exception:
                bal_acc = sens = spec = np.nan
                cond1 = np.inf
                chol_failed = True

            rows.append(dict(n=n, d=d, balanced_acc=bal_acc, sens=sens, spec=spec,
                              cond_clase1=cond1, cholesky_failed=chol_failed))

    return pd.DataFrame(rows)


if __name__ == "__main__":
    from preprocess import run

    out = run(save=False)
    Xtr, ytr = out["X_train"].values, out["y_train"].values
    Xval, yval = out["X_val"].values, out["y_val"].values

    ns = [100, 200, 400, 700, 1021]
    ds = [5, 10, 20, 40, 80, 160, 320]

    print("=== Covarianza completa ===")
    df_full = error_surface(Xtr, ytr, Xval, yval, ns, ds, cov_type="full")
    print(df_full.pivot(index="n", columns="d", values="balanced_acc").round(2))
    print("\nFallos de Cholesky (True = Sigma singular en el primer intento):")
    print(df_full.pivot(index="n", columns="d", values="cholesky_failed"))

    print("\n=== Covarianza con contracción (lambda=0.3) ===")
    df_shrink = error_surface(Xtr, ytr, Xval, yval, ns, ds, cov_type="shrinkage", shrinkage_lambda=0.3)
    print(df_shrink.pivot(index="n", columns="d", values="balanced_acc").round(2))
