"""
Pasos 3.3.3 y 3.3.4: clasificador generativo gaussiano por clase, con tres
familias de estructura de covarianza:
  (a) completa   : Sigma_c = covarianza muestral de la clase c (MLE)
  (b) diagonal    : Sigma_c = diag(var(x)) por clase (ignora correlaciones)
  (c) contraída   : Sigma_lambda = (1-lambda) * Sigma_completa + lambda * D
                     con D = diag(Sigma_completa) (shrinkage hacia la diagonal)

Puntuación discriminante (sección 3.2):
  g_c(x) = -1/2 log|Sigma_c| - 1/2 (x-mu_c)^T Sigma_c^-1 (x-mu_c) + log P(Y=c)

Todo el álgebra pasa por stable_linalg.py (Cholesky, nunca inversa explícita).
"""
import numpy as np
from dataclasses import dataclass, field
from stable_linalg import logdet_and_quadform, condition_number, CholeskyFailure


@dataclass
class GaussianClassClassifier:
    cov_type: str = "full"          # "full" | "diagonal" | "shrinkage"
    shrinkage_lambda: float = 0.1   # solo usado si cov_type == "shrinkage"
    jitter: float = 1e-6            # regularización numérica mínima (no estadística)

    mu_: dict = field(default_factory=dict)
    Sigma_: dict = field(default_factory=dict)
    log_prior_: dict = field(default_factory=dict)
    classes_: list = field(default_factory=list)
    cholesky_failed_: dict = field(default_factory=dict)
    condition_numbers_: dict = field(default_factory=dict)
    jitter_used_: dict = field(default_factory=dict)

    def fit(self, X: np.ndarray, y: np.ndarray):
        self.classes_ = sorted(np.unique(y).tolist())
        n = len(y)
        for c in self.classes_:
            Xc = X[y == c]
            self.mu_[c] = Xc.mean(axis=0)
            Sigma_full = np.cov(Xc, rowvar=False)
            if Sigma_full.ndim == 0:
                Sigma_full = np.array([[Sigma_full]])

            if self.cov_type == "full":
                Sigma = Sigma_full
            elif self.cov_type == "diagonal":
                Sigma = np.diag(np.diag(Sigma_full))
            elif self.cov_type == "shrinkage":
                D = np.diag(np.diag(Sigma_full))
                Sigma = (1 - self.shrinkage_lambda) * Sigma_full + self.shrinkage_lambda * D
            else:
                raise ValueError(f"cov_type desconocido: {self.cov_type}")

            self.Sigma_[c] = Sigma
            self.log_prior_[c] = np.log(len(Xc) / n)
            self.condition_numbers_[c] = condition_number(Sigma)
        return self

    def _discriminant(self, X: np.ndarray):
        """Devuelve matriz (n_muestras, n_clases) de g_c(x). Si Cholesky
        falla para alguna clase, se registra y se usa un jitter creciente
        como último recurso, documentando el fallo."""
        n = X.shape[0]
        scores = np.zeros((n, len(self.classes_)))
        for j, c in enumerate(self.classes_):
            deltas = X - self.mu_[c]
            failed = False
            jitter_schedule = [0.0, max(self.jitter, 1e-8), max(self.jitter, 1e-8) * 100,
                                max(self.jitter, 1e-8) * 10000]
            for attempt, jitter in enumerate(jitter_schedule):
                try:
                    logdet, quad = logdet_and_quadform(self.Sigma_[c], deltas, jitter=jitter)
                    if attempt > 0:
                        failed = True  # el primer intento (sin jitter) SÍ falló: Sigma singular
                    break
                except CholeskyFailure:
                    if attempt == len(jitter_schedule) - 1:
                        raise CholeskyFailure(f"Cholesky falló persistentemente para clase {c}")
            self.cholesky_failed_[c] = failed
            self.jitter_used_[c] = jitter
            d = X.shape[1]
            scores[:, j] = -0.5 * logdet - 0.5 * quad + self.log_prior_[c]
        return scores

    def predict_log_proba(self, X: np.ndarray):
        scores = self._discriminant(X)
        # normalización log-sum-exp para obtener log-posteriores válidas
        m = scores.max(axis=1, keepdims=True)
        logsumexp = m[:, 0] + np.log(np.sum(np.exp(scores - m), axis=1))
        return scores - logsumexp[:, None]

    def predict_proba(self, X: np.ndarray):
        return np.exp(self.predict_log_proba(X))

    def predict(self, X: np.ndarray, threshold: float = 0.5, positive_class=1):
        proba = self.predict_proba(X)
        pos_idx = self.classes_.index(positive_class)
        return (proba[:, pos_idx] >= threshold).astype(int)

    def mean_test_loglik(self, X: np.ndarray, y: np.ndarray):
        """Log-verosimilitud media de prueba: log p(x_i | y_i) evaluada con
        el modelo generativo de la clase VERDADERA (no la predicha)."""
        n = X.shape[0]
        total = 0.0
        for c in self.classes_:
            mask = (y == c)
            if mask.sum() == 0:
                continue
            deltas = X[mask] - self.mu_[c]
            logdet, quad = logdet_and_quadform(self.Sigma_[c], deltas, jitter=self.jitter)
            d = X.shape[1]
            loglik = -0.5 * (d * np.log(2 * np.pi) + logdet + quad)
            total += loglik.sum()
        return total / n
