"""
Núcleo de álgebra lineal computacional estable (sección 3.3, punto 5).

Regla de oro: NUNCA invertir Sigma explícitamente. En su lugar:
  - factorización de Cholesky Sigma = L L^T (Sigma debe ser SPD)
  - log|Sigma| = 2 * sum(log(diag(L)))            (evita overflow/underflow)
  - Sigma^-1 v  se obtiene resolviendo L L^T x = v con sustitución
    hacia adelante/atrás (scipy.linalg.cho_solve), nunca con Sigma^-1 explícita.
  - la forma cuadrática (x-mu)^T Sigma^-1 (x-mu) se calcula resolviendo
    L z = (x-mu) y tomando ||z||^2 (equivalente, más barato y más estable).

Si Cholesky falla (Sigma no es SPD, típicamente por alta dimensión con
pocas observaciones), se reporta explícitamente el fallo: es información
científica valiosa, no un error a esconder con un try/except silencioso.
"""
import numpy as np
from scipy.linalg import cho_factor, cho_solve, LinAlgError


class CholeskyFailure(Exception):
    """Señala que Sigma no es numéricamente SPD (fallo de Cholesky)."""
    pass


def safe_cholesky(Sigma: np.ndarray, jitter: float = 0.0):
    """Intenta la factorización de Cholesky. Si jitter > 0, se suma
    jitter*I como último recurso ANTES de declarar fallo (regularización
    numérica mínima, distinta de la contracción estadística de shrinkage.py)."""
    S = Sigma if jitter == 0 else Sigma + jitter * np.eye(Sigma.shape[0])
    try:
        c, lower = cho_factor(S, lower=True, check_finite=False)
        return c, lower
    except LinAlgError as e:
        raise CholeskyFailure(str(e))


def logdet_and_quadform(Sigma: np.ndarray, deltas: np.ndarray, jitter: float = 0.0):
    """Calcula log|Sigma| y la forma cuadrática delta^T Sigma^-1 delta
    para cada fila de 'deltas' (n x d), sin invertir Sigma.
    Devuelve (logdet, quad[n]). Lanza CholeskyFailure si Sigma no es SPD."""
    c, lower = safe_cholesky(Sigma, jitter=jitter)
    L = np.tril(c) if lower else np.triu(c).T
    logdet = 2.0 * np.sum(np.log(np.diag(c)))

    # resolver L z = delta^T para cada fila: usamos cho_solve con el factor
    # completo para obtener Sigma^-1 delta, luego el producto punto da la forma cuadrática
    inv_deltas = cho_solve((c, lower), deltas.T, check_finite=False).T  # (n, d)
    quad = np.einsum('ij,ij->i', deltas, inv_deltas)
    return logdet, quad


def condition_number(Sigma: np.ndarray):
    """Número de condición (norma-2) = lambda_max/lambda_min de Sigma.
    Un número de condición muy grande (>>1e6) anticipa problemas de
    Cholesky y de estabilidad en la clasificación gaussiana."""
    eigvals = np.linalg.eigvalsh(Sigma)
    eigvals = eigvals[eigvals > 0]
    if len(eigvals) == 0:
        return np.inf
    return float(eigvals.max() / eigvals.min())


def mahalanobis_sq(x: np.ndarray, mu: np.ndarray, Sigma: np.ndarray, jitter: float = 0.0):
    """Distancia de Mahalanobis al cuadrado, vía Cholesky (sin invertir Sigma)."""
    deltas = np.atleast_2d(x) - mu
    _, quad = logdet_and_quadform(Sigma, deltas, jitter=jitter)
    return quad
