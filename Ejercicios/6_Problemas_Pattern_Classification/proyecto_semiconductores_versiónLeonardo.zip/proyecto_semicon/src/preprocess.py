"""
Paso 1 de la ruta computacional (Problema 2: fallas en semiconductores, SECOM).

 - Auditoría de variables: eliminar columnas constantes/casi constantes,
   cuantificar faltantes.
 - Partición estratificada train/val/test, preservando la clase minoritaria
   (fallo, 104/1567 ~ 6.6%).
 - Estandarización e imputación de faltantes (media) calculadas SOLO con
   el conjunto de entrenamiento, para evitar fuga de información.
"""
import numpy as np
import pandas as pd
from pathlib import Path

RAW_DIR = Path(__file__).resolve().parents[1] / "data_raw"
PROCESSED_DIR = Path(__file__).resolve().parents[1] / "data_processed"


def load_raw():
    X = pd.read_csv(RAW_DIR / "secom.data", sep=r"\s+", header=None, na_values="NaN")
    X.columns = [f"f{i:03d}" for i in range(X.shape[1])]
    y_raw = pd.read_csv(RAW_DIR / "secom_labels.data", sep=" ", header=None,
                         names=["label", "time"])
    y = (y_raw["label"] == 1).astype(int)  # 1 = fallo, 0 = pasa
    time = pd.to_datetime(y_raw["time"].str.strip('"'), format="%d/%m/%Y %H:%M:%S")
    return X, y, time


def audit_columns(X: pd.DataFrame, missing_thresh: float = 0.5, var_thresh: float = 1e-10):
    """Elimina columnas con demasiados faltantes o varianza casi nula.
    Devuelve el DataFrame filtrado y un reporte de auditoría."""
    missing_frac = X.isna().mean()
    too_missing = missing_frac[missing_frac > missing_thresh].index.tolist()

    var = X.var(skipna=True)
    near_constant = var[var < var_thresh].index.tolist()

    drop_cols = sorted(set(too_missing) | set(near_constant))
    X_audited = X.drop(columns=drop_cols)

    report = dict(
        n_original=X.shape[1],
        n_dropped_missing=len(too_missing),
        n_dropped_constant=len(near_constant),
        n_remaining=X_audited.shape[1],
        missing_frac_remaining=X_audited.isna().mean().mean(),
    )
    return X_audited, report


def stratified_split(X: pd.DataFrame, y: pd.Series, time: pd.Series,
                      val_frac: float = 0.15, test_frac: float = 0.2, seed: int = 42):
    """Partición estratificada (preserva proporción de fallos en cada bloque)."""
    rng = np.random.default_rng(seed)
    idx_pos = y[y == 1].index.to_numpy().copy()
    idx_neg = y[y == 0].index.to_numpy().copy()
    rng.shuffle(idx_pos)
    rng.shuffle(idx_neg)

    def split_idx(idx):
        n = len(idx)
        n_test = int(n * test_frac)
        n_val = int(n * val_frac)
        return idx[n_test + n_val:], idx[n_test:n_test + n_val], idx[:n_test]

    tr_pos, val_pos, te_pos = split_idx(idx_pos)
    tr_neg, val_neg, te_neg = split_idx(idx_neg)

    train_idx = np.concatenate([tr_pos, tr_neg])
    val_idx = np.concatenate([val_pos, val_neg])
    test_idx = np.concatenate([te_pos, te_neg])
    rng.shuffle(train_idx); rng.shuffle(val_idx); rng.shuffle(test_idx)

    return train_idx, val_idx, test_idx


def fit_standardizer(X_train: pd.DataFrame):
    """Media/desviación e imputación de faltantes, calculadas SOLO en train."""
    mean = X_train.mean(skipna=True)
    std = X_train.std(skipna=True).replace(0, 1.0)
    return mean, std


def transform(X: pd.DataFrame, mean: pd.Series, std: pd.Series):
    X_imputed = X.fillna(mean)
    return (X_imputed - mean) / std


def run(save: bool = True, missing_thresh: float = 0.5, var_thresh: float = 1e-10):
    X, y, time = load_raw()
    X_audited, audit_report = audit_columns(X, missing_thresh, var_thresh)
    train_idx, val_idx, test_idx = stratified_split(X_audited, y, time)

    mean, std = fit_standardizer(X_audited.loc[train_idx])
    X_train = transform(X_audited.loc[train_idx], mean, std)
    X_val = transform(X_audited.loc[val_idx], mean, std)
    X_test = transform(X_audited.loc[test_idx], mean, std)

    y_train, y_val, y_test = y.loc[train_idx], y.loc[val_idx], y.loc[test_idx]

    if save:
        PROCESSED_DIR.mkdir(exist_ok=True)
        X_train.to_csv(PROCESSED_DIR / "X_train.csv", index=False)
        X_val.to_csv(PROCESSED_DIR / "X_val.csv", index=False)
        X_test.to_csv(PROCESSED_DIR / "X_test.csv", index=False)
        y_train.to_csv(PROCESSED_DIR / "y_train.csv", index=False)
        y_val.to_csv(PROCESSED_DIR / "y_val.csv", index=False)
        y_test.to_csv(PROCESSED_DIR / "y_test.csv", index=False)

    return dict(X_train=X_train, X_val=X_val, X_test=X_test,
                y_train=y_train, y_val=y_val, y_test=y_test,
                audit_report=audit_report)


if __name__ == "__main__":
    out = run(save=True)
    r = out["audit_report"]
    print(f"Variables originales: {r['n_original']}")
    print(f"Eliminadas por faltantes (> {50}%): {r['n_dropped_missing']}")
    print(f"Eliminadas por varianza casi nula: {r['n_dropped_constant']}")
    print(f"Variables remanentes: {r['n_remaining']}")
    print(f"Faltante promedio remanente: {r['missing_frac_remaining']*100:.2f}%")
    print(f"\nTrain: {len(out['y_train'])} (fallos={out['y_train'].sum()})")
    print(f"Val:   {len(out['y_val'])} (fallos={out['y_val'].sum()})")
    print(f"Test:  {len(out['y_test'])} (fallos={out['y_test'].sum()})")
