"""
Paso 4 de la ruta computacional: selección de lambda (contracción de
covarianza) EN VALIDACIÓN, nunca en el conjunto de prueba final.

Sigma_lambda = (1-lambda) * Sigma_completa + lambda * D,  D = diag(Sigma_completa)

Se evalúa una malla de lambda en [0,1] y se elige la que maximiza la
log-verosimilitud media de validación (criterio estadístico) reportando
también el balanced accuracy (criterio orientado a la tarea), para que el
estudiante compare ambos criterios de selección.
"""
import numpy as np
from gaussian_classifier import GaussianClassClassifier


def balanced_accuracy(y_true, y_pred):
    tp = np.sum((y_pred == 1) & (y_true == 1))
    fn = np.sum((y_pred == 0) & (y_true == 1))
    tn = np.sum((y_pred == 0) & (y_true == 0))
    fp = np.sum((y_pred == 1) & (y_true == 0))
    sens = tp / (tp + fn) if (tp + fn) > 0 else np.nan
    spec = tn / (tn + fp) if (tn + fp) > 0 else np.nan
    return 0.5 * (sens + spec), sens, spec


def select_lambda(X_train, y_train, X_val, y_val,
                   lambda_grid=None, criterion="loglik"):
    """Devuelve (mejor_lambda, tabla_resultados). criterion en {'loglik','balanced_acc'}."""
    if lambda_grid is None:
        lambda_grid = np.concatenate([[0.0], np.geomspace(0.001, 1.0, 25)])

    rows = []
    for lam in lambda_grid:
        clf = GaussianClassClassifier(cov_type="shrinkage", shrinkage_lambda=lam).fit(X_train, y_train)
        loglik = clf.mean_test_loglik(X_val, y_val)
        preds = clf.predict(X_val)
        bal_acc, sens, spec = balanced_accuracy(y_val, preds)
        cond1 = clf.condition_numbers_[1]
        rows.append(dict(lam=lam, loglik=loglik, balanced_acc=bal_acc,
                          sens=sens, spec=spec, cond_clase1=cond1,
                          cholesky_failed=clf.cholesky_failed_[1]))

    key = "loglik" if criterion == "loglik" else "balanced_acc"
    best = max(rows, key=lambda r: (r[key] if np.isfinite(r[key]) else -np.inf))
    return best["lam"], rows


if __name__ == "__main__":
    from preprocess import run

    out = run(save=False)
    Xtr, ytr = out["X_train"].values, out["y_train"].values
    Xval, yval = out["X_val"].values, out["y_val"].values

    best_lam, rows = select_lambda(Xtr, ytr, Xval, yval, criterion="loglik")
    print(f"Mejor lambda (criterio log-verosimilitud): {best_lam:.4f}\n")
    print(f"{'lambda':>8s}  {'loglik':>10s}  {'bal_acc':>8s}  {'sens':>6s}  {'spec':>6s}  {'cond(clase1)':>14s}  {'chol_fail':>9s}")
    for r in rows:
        print(f"{r['lam']:8.4f}  {r['loglik']:10.2f}  {r['balanced_acc']:8.3f}  "
              f"{r['sens']:6.2f}  {r['spec']:6.2f}  {r['cond_clase1']:14.2e}  {str(r['cholesky_failed']):>9s}")
