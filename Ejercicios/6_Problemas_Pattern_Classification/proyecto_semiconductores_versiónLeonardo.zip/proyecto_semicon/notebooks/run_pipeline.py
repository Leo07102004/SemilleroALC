"""
Script maestro del Problema 2 (fallas en fabricación de semiconductores, SECOM).
Genera en results/: figuras (.png), tablas (.csv) y un reporte textual.
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pathlib import Path

from preprocess import run as run_preprocess
from feature_ranking import rank_features_ttest
from gaussian_classifier import GaussianClassClassifier
from shrinkage import select_lambda, balanced_accuracy
from evaluation import (confusion_matrix, sensitivity_specificity,
                         precision_recall_curve, average_precision,
                         cost_sensitive_threshold)
from experiment_nd import error_surface

RESULTS_DIR = Path(__file__).resolve().parents[1] / "results"
D_MAIN = 30  # dimensión moderada para la comparación principal de familias de covarianza


def main():
    RESULTS_DIR.mkdir(exist_ok=True)
    report = []

    def log(msg=""):
        print(msg)
        report.append(str(msg))

    log("=" * 70)
    log("PROBLEMA 2: detección probabilística de fallas en semiconductores (SECOM)")
    log("=" * 70)

    # --- 1. auditoría + partición estratificada ---
    out = run_preprocess(save=True)
    r = out["audit_report"]
    log(f"\nVariables: {r['n_original']} originales -> {r['n_remaining']} tras auditoría "
        f"(se eliminaron {r['n_dropped_missing']} por faltantes >50% y "
        f"{r['n_dropped_constant']} casi constantes)")
    log(f"Train: {len(out['y_train'])} (fallos={int(out['y_train'].sum())}, "
        f"{100*out['y_train'].mean():.1f}%)")
    log(f"Val:   {len(out['y_val'])} (fallos={int(out['y_val'].sum())})")
    log(f"Test:  {len(out['y_test'])} (fallos={int(out['y_test'].sum())})")

    Xtr, ytr = out["X_train"].values, out["y_train"].values
    Xval, yval = out["X_val"].values, out["y_val"].values
    Xte, yte = out["X_test"].values, out["y_test"].values

    # --- selección de variables moderada (D_MAIN) para la comparación principal ---
    order, t_stat = rank_features_ttest(Xtr, ytr)
    cols_main = order[:D_MAIN]
    Xtr_m, Xval_m, Xte_m = Xtr[:, cols_main], Xval[:, cols_main], Xte[:, cols_main]
    log(f"\nComparación principal de covarianzas con d={D_MAIN} variables "
        f"(top |t-estadístico| en train).")

    # --- 3. tres familias de covarianza, evaluadas en TEST ---
    log("\n--- Comparación de familias de covarianza (d=30, evaluado en test) ---")
    comparison_rows = []
    for cov_type, kw, label in [("full", {}, "Completa"),
                                  ("diagonal", {}, "Diagonal"),
                                  ("shrinkage", {"shrinkage_lambda": 0.3}, "Contraída (λ=0.3 fijo)")]:
        clf = GaussianClassClassifier(cov_type=cov_type, **kw).fit(Xtr_m, ytr)
        preds = clf.predict(Xte_m)
        cm = confusion_matrix(yte, preds)
        sens, spec = sensitivity_specificity(cm)
        loglik = clf.mean_test_loglik(Xte_m, yte)
        cond1 = clf.condition_numbers_[1]
        log(f"{label:24s} sens={sens:.2f}  spec={spec:.2f}  "
            f"cond(Σ_clase1)={cond1:.2e}  loglik_test={loglik:.2f}  "
            f"chol_fallo(clase1)={clf.cholesky_failed_[1]}")
        comparison_rows.append(dict(familia=label, sensibilidad=sens, especificidad=spec,
                                     cond_clase1=cond1, loglik_test=loglik,
                                     cholesky_fallo=clf.cholesky_failed_[1]))
    pd.DataFrame(comparison_rows).to_csv(RESULTS_DIR / "tabla_comparacion_covarianzas.csv", index=False)

    # --- 4. selección de lambda en validación ---
    log("\n--- Selección de lambda de contracción (criterio: log-verosimilitud en validación) ---")
    best_lam_ll, rows_ll = select_lambda(Xtr_m, ytr, Xval_m, yval, criterion="loglik")
    log(f"Mejor lambda (log-verosimilitud): {best_lam_ll:.4f}")
    best_lam_ba, rows_ba = select_lambda(Xtr_m, ytr, Xval_m, yval, criterion="balanced_acc")
    log(f"Mejor lambda (balanced accuracy):  {best_lam_ba:.4f}")
    log("(Nota: los dos criterios discrepan bastante: balanced_acc se calcula sobre solo "
        "15 positivos de validación y es MUY ruidoso; se prefiere log-verosimilitud, "
        "un criterio estadístico agregado y más estable, para el clasificador final)")
    pd.DataFrame(rows_ll).to_csv(RESULTS_DIR / "tabla_lambda_seleccion.csv", index=False)

    # clasificador final con el lambda elegido por log-verosimilitud (criterio más robusto
    # dado el tamaño ínfimo de la clase minoritaria en validación)
    clf_final = GaussianClassClassifier(cov_type="shrinkage", shrinkage_lambda=best_lam_ll).fit(Xtr_m, ytr)
    proba_test = clf_final.predict_proba(Xte_m)[:, clf_final.classes_.index(1)]

    # --- 3.5. curva precisión-recall ---
    recalls, precisions, thresholds = precision_recall_curve(yte, proba_test)
    ap = average_precision(recalls, precisions)
    log(f"\nÁrea bajo la curva precisión-recall (test, λ={best_lam_ll:.3f}): {ap:.3f}")

    # --- 3.3.7. decisión sensible al costo ---
    cost_fn, cost_fp = 10.0, 1.0  # omitir un fallo cuesta 10x una falsa alarma
    best_t, best_cost, t_grid, costs = cost_sensitive_threshold(yte, proba_test, cost_fn, cost_fp)
    pred_cost_sensitive = (proba_test >= best_t).astype(int)
    cm_cost = confusion_matrix(yte, pred_cost_sensitive)
    sens_cost, spec_cost = sensitivity_specificity(cm_cost)
    log(f"\nUmbral óptimo sensible al costo (costo_FN={cost_fn}, costo_FP={cost_fp}): {best_t:.3f}")
    log(f"Con ese umbral: sensibilidad={sens_cost:.2f}, especificidad={spec_cost:.2f}, "
        f"costo total={best_cost:.0f}")
    cm_default = confusion_matrix(yte, (proba_test >= 0.5).astype(int))
    sens_def, spec_def = sensitivity_specificity(cm_default)
    log(f"Con umbral por defecto (0.5): sensibilidad={sens_def:.2f}, especificidad={spec_def:.2f}, "
        f"costo total={cost_fn*cm_default['fn'] + cost_fp*cm_default['fp']:.0f}")

    # --- 6. experimento n vs d (covarianza completa vs. contraída) ---
    log("\n--- Experimento n vs. d: superficie de error y estabilidad numérica ---")
    ns = [100, 200, 400, 700, 1021]
    ds = [5, 10, 20, 40, 80, 160, 320]
    df_full = error_surface(Xtr, ytr, Xval, yval, ns, ds, cov_type="full")
    df_shrink = error_surface(Xtr, ytr, Xval, yval, ns, ds, cov_type="shrinkage", shrinkage_lambda=0.3)
    df_full.to_csv(RESULTS_DIR / "tabla_nd_full.csv", index=False)
    df_shrink.to_csv(RESULTS_DIR / "tabla_nd_shrinkage.csv", index=False)

    frontera = df_full[~df_full["cholesky_failed"]].groupby("n")["d"].max()
    log("Frontera empírica de estabilidad (covarianza completa) — máximo d con Cholesky exitoso, por n:")
    for n, d in frontera.items():
        log(f"  n={n:5d}  ->  d_max_estable={d}")

    # ===================== FIGURAS =====================

    # Fig 1: comparación de familias de covarianza (barras sens/spec)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    labels = [r["familia"] for r in comparison_rows]
    sens_vals = [r["sensibilidad"] for r in comparison_rows]
    spec_vals = [r["especificidad"] for r in comparison_rows]
    x = np.arange(len(labels))
    w = 0.35
    ax.bar(x - w/2, sens_vals, w, label="Sensibilidad (detectar fallos)", color="#d62728")
    ax.bar(x + w/2, spec_vals, w, label="Especificidad (no falsas alarmas)", color="#1f77b4")
    ax.set_xticks(x); ax.set_xticklabels(labels)
    ax.set_ylim(0, 1.05)
    ax.set_title(f"Comparación de familias de covarianza (d={D_MAIN}, evaluado en test)")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(RESULTS_DIR / "fig_comparacion_covarianzas.png", dpi=150)
    plt.close(fig)

    # Fig 2: selección de lambda (loglik y balanced accuracy)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4))
    lams = [r["lam"] for r in rows_ll]
    ax1.plot(lams, [r["loglik"] for r in rows_ll], color="#2ca02c", marker="o", markersize=3)
    ax1.axvline(best_lam_ll, color="gray", linestyle="--", linewidth=1)
    ax1.set_xlabel(r"$\lambda$ (contracción)"); ax1.set_ylabel("log-verosimilitud (val.)")
    ax1.set_title("Selección por log-verosimilitud")

    ax2.plot(lams, [r["balanced_acc"] for r in rows_ba], color="#ff7f0e", marker="o", markersize=3)
    ax2.axvline(best_lam_ba, color="gray", linestyle="--", linewidth=1)
    ax2.set_xlabel(r"$\lambda$ (contracción)"); ax2.set_ylabel("balanced accuracy (val.)")
    ax2.set_title("Selección por balanced accuracy")
    fig.tight_layout()
    fig.savefig(RESULTS_DIR / "fig_seleccion_lambda.png", dpi=150)
    plt.close(fig)

    # Fig 3: curva precisión-recall
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(recalls, precisions, color="#9467bd", marker=".", markersize=4)
    ax.set_xlabel("Recall (sensibilidad)"); ax.set_ylabel("Precisión")
    ax.set_title(f"Curva precisión-recall (test, λ={best_lam_ll:.3f})\nAP={ap:.3f}")
    ax.set_xlim(-0.02, 1.02); ax.set_ylim(-0.02, 1.02)
    fig.tight_layout()
    fig.savefig(RESULTS_DIR / "fig_precision_recall.png", dpi=150)
    plt.close(fig)

    # Fig 4: heatmap balanced accuracy, covarianza completa
    fig, axes = plt.subplots(1, 2, figsize=(13, 4.5))
    for ax, df, title in [(axes[0], df_full, "Covarianza completa"),
                           (axes[1], df_shrink, "Covarianza contraída (λ=0.3)")]:
        piv = df.pivot(index="n", columns="d", values="balanced_acc")
        im = ax.imshow(piv.values, aspect="auto", cmap="viridis", vmin=0.4, vmax=0.65)
        ax.set_xticks(range(len(piv.columns))); ax.set_xticklabels(piv.columns)
        ax.set_yticks(range(len(piv.index))); ax.set_yticklabels(piv.index)
        ax.set_xlabel("d (número de variables)"); ax.set_ylabel("n (observaciones de entrenamiento)")
        ax.set_title(f"E(n,d): balanced accuracy\n{title}")
        fig.colorbar(im, ax=ax, fraction=0.046)
    fig.tight_layout()
    fig.savefig(RESULTS_DIR / "fig_superficie_error.png", dpi=150)
    plt.close(fig)

    # Fig 5: frontera de estabilidad de Cholesky (staircase n vs d)
    fig, ax = plt.subplots(figsize=(7, 5))
    piv_fail = df_full.pivot(index="n", columns="d", values="cholesky_failed").astype(float)
    im = ax.imshow(piv_fail.values, aspect="auto", cmap="RdYlGn_r", vmin=0, vmax=1)
    ax.set_xticks(range(len(piv_fail.columns))); ax.set_xticklabels(piv_fail.columns)
    ax.set_yticks(range(len(piv_fail.index))); ax.set_yticklabels(piv_fail.index)
    ax.set_xlabel("d (número de variables)"); ax.set_ylabel("n (observaciones de entrenamiento)")
    ax.set_title("Frontera de singularidad de Σ̂ (covarianza completa)\nrojo = falla Cholesky (sin jitter)")
    fig.tight_layout()
    fig.savefig(RESULTS_DIR / "fig_frontera_cholesky.png", dpi=150)
    plt.close(fig)

    # Fig 6: costo esperado vs. umbral
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(t_grid, costs, color="#8c564b")
    ax.axvline(best_t, color="red", linestyle="--", label=f"óptimo t={best_t:.3f}")
    ax.axvline(0.5, color="gray", linestyle=":", label="umbral por defecto t=0.5")
    ax.set_xlabel("Umbral de decisión sobre P(fallo | x)")
    ax.set_ylabel(f"Costo esperado (costo_FN={cost_fn}, costo_FP={cost_fp})")
    ax.set_title("Decisión sensible al costo")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(RESULTS_DIR / "fig_costo_umbral.png", dpi=150)
    plt.close(fig)

    with open(RESULTS_DIR / "reporte.txt", "w") as f:
        f.write("\n".join(report))

    log(f"\nFiguras y tablas guardadas en: {RESULTS_DIR}")


if __name__ == "__main__":
    main()
