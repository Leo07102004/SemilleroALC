# Problema 2 — Detección probabilística de fallas en fabricación de semiconductores

Implementación computacional completa del Problema 2 de la propuesta
*"Seis problemas reales para aplicar estimación probabilística y modelos
latentes"* (capítulo 3 de Duda, Hart & Stork, *Pattern Classification*).

**Por qué este proyecto para un semillero de álgebra lineal computacional:**
su núcleo matemático completo vive en el manejo de matrices de covarianza
de alta dimensión — factorización de Cholesky, log-determinantes sin
inversión explícita, número de condición, singularidad, y regularización
por contracción (shrinkage) de un estimador mal condicionado. Es el
proyecto de los seis cuyo objeto de estudio *es* el álgebra lineal
numérica, no solo una herramienta auxiliar.

Dataset: **SECOM — UCI Machine Learning Repository**. 1567 observaciones,
590 variables anónimas de proceso, 104 fallos (6.6%, fuertemente
desbalanceado).

## Pregunta central

¿Qué estructura de modelo gaussiano permite detectar fallos con mayor
estabilidad numérica cuando el número de variables es grande en relación
con el número de observaciones?

## Estructura del repositorio

```
proyecto_semicon/
  data_raw/              # secom.data, secom_labels.data (originales, no modificar)
  data_processed/        # generado por src/preprocess.py
  src/
    preprocess.py          # Paso 1: auditoría de variables, partición estratificada
    stable_linalg.py        # Paso 5: Cholesky, logdet, forma cuadrática, número de condición
    gaussian_classifier.py   # Paso 3: clasificador gaussiano (completa/diagonal/contraída)
    feature_ranking.py       # ranking t-test (train-only), usado en el experimento n vs d
    shrinkage.py              # Paso 4: selección de lambda en validación
    evaluation.py              # Sección 3.5: matriz de confusión, PR, umbral sensible al costo
    experiment_nd.py           # Paso 6: superficie de error E(n,d) y frontera de estabilidad
  notebooks/
    run_pipeline.py         # script maestro: corre todo y genera results/
  results/                  # figuras (.png) y tablas (.csv) generadas
  tests/
    test_core.py             # pruebas unitarias del álgebra lineal y el clasificador
  requirements.txt
  README.md
```

## Cómo reproducir

```bash
pip install -r requirements.txt
python3 tests/test_core.py
cd notebooks
PYTHONPATH=../src python3 run_pipeline.py
```

Esto genera en `results/`:
- `fig_frontera_cholesky.png` — **la figura central del proyecto**: mapa
  n×d donde rojo indica que Σ̂ no es numéricamente SPD (Cholesky falla sin
  regularización). Reproduce la teoría de forma exacta: la frontera sigue
  aproximadamente `d ≈ n_clase − 1`.
- `fig_superficie_error.png` — balanced accuracy en función de (n,d) para
  covarianza completa vs. contraída.
- `fig_comparacion_covarianzas.png` — sensibilidad/especificidad de las
  tres familias de covarianza a d=30.
- `fig_seleccion_lambda.png` — curvas de selección de λ (log-verosimilitud
  vs. balanced accuracy en validación).
- `fig_precision_recall.png`, `fig_costo_umbral.png`
- `tabla_*.csv`, `reporte.txt`

## Núcleo matemático (implementado desde cero, sección `stable_linalg.py`)

Regla de oro seguida en todo el proyecto: **nunca invertir Σ explícitamente**.

- `Σ = L Lᵀ` (Cholesky), `log|Σ| = 2·Σ log(diag(L))`
- `Σ⁻¹v` se obtiene resolviendo el sistema triangular, no invirtiendo
- distancia de Mahalanobis: `‖L⁻¹(x−μ)‖²`, no `(x−μ)ᵀΣ⁻¹(x−μ)` con Σ⁻¹ explícita
- si Cholesky falla (Σ no es SPD, típico cuando `n_clase < d`), el fallo se
  **reporta explícitamente** como hallazgo, no se oculta con un try/except

Validado contra la inversión explícita de NumPy hasta precisión de máquina
(`test_logdet_quadform_matches_explicit_inverse`).

## Resultados principales

### 1. Frontera de singularidad (hallazgo central)

| n (train) | d máximo con Σ̂ numéricamente SPD |
|---|---|
| 200  | 10 |
| 400  | 20 |
| 700  | 40 |
| 1021 | 40 |

La frontera crece con n de forma consistente con la teoría: el rango de
Σ̂ para una clase con `n_c` observaciones está acotado por `n_c − 1`; con
solo 69 fallos en entrenamiento, la covarianza completa de esa clase
nunca puede ser de rango completo más allá de d≈68.

### 2. Comparación de familias de covarianza (d=30, test)

| Familia | Sensibilidad | Especificidad | cond(Σ̂ clase fallo) |
|---|---|---|---|
| Completa | 0.35 | 0.71 | 3.9×10⁵ |
| Diagonal | 0.85 | 0.38 | 1.8×10² |
| Contraída (λ=0.3) | 0.90 | 0.36 | 8.6×10² |

La covarianza completa es conservadora (pocas alarmas, pero detecta pocos
fallos reales); diagonal y contraída detectan muchos más fallos a costa
de muchas más falsas alarmas — el clásico compromiso sesgo-varianza del
capítulo 3, aquí visible en números de condición de varios órdenes de
magnitud de diferencia.

### 3. Selección de λ: dos criterios que discrepan

- Por log-verosimilitud (agregada, estable): λ ≈ 0.032
- Por balanced accuracy en validación (solo 15 positivos): λ ≈ 0.002

La gran discrepancia es en sí un hallazgo: con una clase minoritaria de
15 observaciones en validación, cualquier métrica de clasificación
(sensibilidad, balanced accuracy) tiene varianza enorme. La
log-verosimilitud, al promediar sobre TODAS las observaciones (no solo
los aciertos/errores de la clase rara), es un criterio de selección
mucho más estable — aunque no está directamente alineado con el objetivo
final de detectar fallos. **Se usó λ por log-verosimilitud para el
clasificador final**, documentando explícitamente esta decisión.

### 4. Decisión sensible al costo

Con costo(falso negativo) = 10 × costo(falsa alarma):

| Umbral | Sensibilidad | Especificidad | Costo total |
|---|---|---|---|
| 0.5 (por defecto) | 0.65 | 0.50 | 217 |
| 0.994 (óptimo) | 0.45 | 0.82 | 164 |

Contraintuitivamente, el umbral óptimo bajo este costo es **sensibilidad
menor**: cuando el falso negativo es 10× más costoso pero las falsas
alarmas ya eran muy frecuentes con el umbral por defecto, el óptimo
prioriza reducir el volumen total de alarmas mientras conserva las más
confiables. Este resultado depende fuertemente de la razón de costos
elegida — se recomienda a los estudiantes explorar la sensibilidad a
distintas razones costo_FN/costo_FP.

## Precaución metodológica (sección 3.5 del documento base)

Con 591 variables y solo 1567 observaciones (104 fallos), la selección de
variables puede contaminar la evaluación si se hace con todo el conjunto.
**En este proyecto, el ranking t-test se recalcula siempre solo con el
bloque de entrenamiento** (y, en el experimento n vs. d, solo con la
submuestra de entrenamiento correspondiente a cada celda), para no filtrar
información de validación/prueba hacia la selección de variables.

## Rendimiento en contexto

El desempeño obtenido (balanced accuracy ≈ 0.55–0.62 en las mejores
combinaciones) es modesto en términos absolutos, pero consistente con la
dificultad documentada del dataset SECOM en la literatura (tasas de error
balanceado reportadas ≈ 33–40% con métodos de selección de características
más sofisticados). El valor del proyecto no está en superar esas cifras,
sino en **hacer visible, con matemáticas explícitas y auditables, por qué
el problema es difícil**: alta dimensión, desbalance extremo, y el
compromiso ineludible entre flexibilidad del modelo (covarianza completa)
y estabilidad numérica.

## Extensión sugerida para el informe final

1. Comparar contra un análisis discriminante regularizado (RDA) con dos
   parámetros de contracción (hacia la diagonal y hacia una covarianza
   común entre clases — pooled), y estudiar el plano 2D de selección.
2. Usar validación cruzada estratificada (en vez de una sola partición
   train/val/test) para reducir la varianza del criterio de selección de
   λ observada en este informe.
3. Sustituir el ranking univariado t-test por un método multivariante
   (p. ej., LASSO logístico) y comparar la superficie E(n,d) resultante.
