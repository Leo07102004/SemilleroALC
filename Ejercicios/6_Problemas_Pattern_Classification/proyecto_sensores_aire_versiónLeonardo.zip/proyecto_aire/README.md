# Problema 1 — Monitoreo y recalibración de sensores de calidad del aire

Implementación computacional completa del Problema 1 de la propuesta
*"Seis problemas reales para aplicar estimación probabilística y modelos
latentes"* (capítulo 3 de Duda, Hart & Stork, *Pattern Classification*).

Dataset: **Air Quality — UCI Machine Learning Repository** (9358 registros
horarios, 5 sensores químicos de bajo costo + analizador de referencia,
marzo 2004 – abril 2005, con deriva documentada y valores faltantes
codificados como `-200`).

## Pregunta central

¿Puede un sistema actualizar en tiempo real la estimación del sesgo de un
sensor, cuantificar la incertidumbre residual y detectar tempranamente
cuándo el comportamiento del dispositivo cambia?

## Estructura del repositorio

```
proyecto_aire/
  data_raw/            # AirQualityUCI.csv (dataset original, no modificar)
  data_processed/      # generado por src/preprocess.py
  src/
    preprocess.py       # Paso 1: preparación temporal, NA, partición cronológica
    calibration.py       # Paso 2: modelo base g(s_t) y residuos e_t
    bayes_recursive.py    # Pasos 3-4: normal-normal, actualización recursiva (con olvido)
    alerts_drift.py       # Pasos 5-6: alertas puntuales y detección de deriva
    em_multivariate.py    # Paso 7: EM para normal multivariante con datos faltantes
    evaluation.py         # Sección 2.5: métricas de evaluación
  notebooks/
    run_pipeline.py      # script maestro: corre todo y genera results/
  results/               # figuras (.png) y tablas (.csv) generadas
  tests/
    test_core.py          # pruebas unitarias del núcleo bayesiano, calibración y EM
  requirements.txt
  README.md
```

## Cómo reproducir

```bash
pip install -r requirements.txt
python3 -m pytest tests/ -v          # o: python3 tests/test_core.py
cd notebooks
PYTHONPATH=../src python3 run_pipeline.py
```

Esto genera en `results/`:
- `fig_mu_posterior.png` — trayectoria de μₙ con banda posterior ±2σₙ
- `fig_alerts.png` — log-densidad predictiva y alertas puntuales
- `fig_drift_mc.png` — ejemplo controlado de detección de una deriva inyectada
- `tabla_metricas.csv`, `tabla_mle_vs_bayes.csv` — métricas numéricas
- `reporte.txt` — resumen textual de toda la corrida

## Resumen del modelo

- `y_t` = `CO(GT)` (medición de referencia certificada)
- `s_t` = `PT08.S1(CO)` (sensor químico de bajo costo)
- `g(s_t)` = calibración nominal lineal, ajustada por mínimos cuadrados
  **solo** con el bloque de calibración (MLE gaussiano).
- `e_t = y_t − g(s_t)` ~ modelo normal-normal:
  `e_t | μ ~ N(μ, σ²)`, `μ ~ N(μ₀, σ₀²)`.
- Actualización bayesiana recursiva con **factor de olvido** (ρ = 0.995):
  evita que σₙ² colapse a valores arbitrariamente pequeños con memoria
  infinita, lo cual —de otro modo— vuelve al detector insensible en el
  mediano plazo y a la vez hipersensible a ruido normal (hallazgo empírico
  documentado en el código, ver `bayes_recursive.py`).
- Detección de deriva: media móvil de μₙ comparada contra una banda
  adaptativa `k·σₙ`, exigiendo persistencia mínima para evitar falsas
  alarmas por un solo dato extremo.
- Datos faltantes multivariantes: EM implementado desde cero (sin
  librería especializada) para una normal multivariante con patrones de
  faltantes arbitrarios, sobre los 5 sensores conjuntos.

## Resultados obtenidos (ver `results/reporte.txt` para el detalle completo)

| Métrica | Valor |
|---|---|
| MAE antes / después de corrección bayesiana | 0.590 / 0.561 |
| RMSE antes / después | 0.858 / 0.785 |
| Cobertura empírica (nominal 90%) | ≈ 82% |
| Cobertura empírica (nominal 95%) | ≈ 87% |
| Detección de deriva artificial (Monte Carlo, 100 réplicas) | 100%, retraso medio ≈ 49 h |
| Tasa de falsas alarmas (sin deriva) | 0% |
| MLE vs. Bayes, n=3 (MSE) | 0.080 vs. 0.045 |

## Hallazgos y precauciones metodológicas

1. **La cobertura empírica está por debajo del nivel nominal** (82% vs. 90%
   nominal). Esto indica que el modelo normal-normal, aunque razonable
   como primera aproximación, **subestima la incertidumbre real**: los
   residuos muestran un desplazamiento de nivel apenas comienza el
   periodo de evaluación (posiblemente estacional, dado que calibración
   y evaluación cubren meses distintos del año), que el modelo capta con
   retraso. Es un ejemplo real de la precaución del documento base:
   *"una observación improbable no implica automáticamente sensor
   averiado"* — aquí ocurre lo inverso, el modelo es demasiado confiado.
2. **Bayes recursivo con memoria infinita es frágil ante no-estacionariedad.**
   Se documenta explícitamente en el código el motivo por el que se usa
   un factor de olvido: sin él, σₙ² se concentra indefinidamente y el
   detector de deriva se vuelve inutilizable (dispara casi al azar tras
   miles de observaciones). Esta es una limitación real del modelo del
   capítulo 3 cuando se aplica a series temporales largas, y motiva
   discutir extensiones (Bayes con descuento, modelos de espacio de
   estados) en el informe final.
3. El experimento Monte Carlo de detección de deriva se hizo sobre datos
   **simulados y estacionarios** (no sobre los datos reales de evaluación)
   para tener una medición limpia de tiempo de detección y tasa de falsas
   alarmas, ya que los datos reales ya contienen una deriva de nivel desde
   el primer momento de la evaluación (ver punto 1).

## Extensión sugerida para el informe final

Comparar el detector actual (Bayes recursivo con olvido) contra un CUSUM
clásico o un filtro de Kalman con varianza de proceso, y discutir en qué
casos la interpretación bayesiana (posterior completa) aporta algo que un
estadístico de control de procesos clásico no aporta.
