"""
Paso 7 de la ruta computacional: si se modelan varios sensores
conjuntamente, usar una normal multivariante y EM para estimar mu y Sigma
con entradas faltantes (implementación didáctica, sin librería especializada).

Modelo: X_t ~ N_d(mu, Sigma), con posibles NaN en cualquier coordenada.
Algoritmo EM clásico para normal multivariante con missing-at-random (MAR):

  E-step: para cada fila con patrón de faltantes m, se imputa el valor
          esperado de las coordenadas faltantes condicionado en las
          observadas (regresión gaussiana condicional), y se acumula la
          covarianza condicional de las faltantes (para no subestimar Sigma).
  M-step: mu, Sigma se recalculan con los valores completados y las
          covarianzas condicionales sumadas ("correction term").
"""
import numpy as np


def _complete_case_init(X: np.ndarray):
    """Inicialización con casos completos (o con media/varianza por
    columna si no hay suficientes casos completos)."""
    mask = ~np.isnan(X)
    complete = X[mask.all(axis=1)]
    if len(complete) >= X.shape[1] + 1:
        mu = complete.mean(axis=0)
        Sigma = np.cov(complete, rowvar=False)
    else:
        mu = np.nanmean(X, axis=0)
        Sigma = np.diag(np.nanvar(X, axis=0) + 1e-6)
    return mu, Sigma


def em_missing_gaussian(X: np.ndarray, max_iter: int = 100, tol: float = 1e-6, verbose: bool = False):
    """EM para N(mu, Sigma) con NaN indicando datos faltantes.
    Devuelve mu, Sigma estimados y el historial de log-verosimilitud
    observada (marginal) por iteración."""
    X = np.asarray(X, dtype=float)
    n, d = X.shape
    mu, Sigma = _complete_case_init(X)

    # agrupar filas por patrón de faltantes (mismo patrón -> mismo álgebra)
    obs_mask = ~np.isnan(X)
    patterns = {}
    for i in range(n):
        key = tuple(obs_mask[i])
        patterns.setdefault(key, []).append(i)

    loglik_history = []
    jitter = 1e-8

    for it in range(max_iter):
        X_filled = X.copy()
        # acumulador del término de corrección de covarianza (E[xx^T] - mu mu^T ajustado)
        C_sum = np.zeros((d, d))
        loglik = 0.0

        for key, idxs in patterns.items():
            obs_idx = np.where(key)[0]
            mis_idx = np.where(~np.array(key))[0]
            rows = np.array(idxs)

            if len(mis_idx) == 0:
                # sin faltantes: no hay incertidumbre residual en este patrón
                diffs = X[rows] - mu
                Sigma_reg = Sigma + jitter * np.eye(d)
                sign, logdet = np.linalg.slogdet(Sigma_reg)
                inv = np.linalg.inv(Sigma_reg)
                quad = np.einsum('ij,jk,ik->i', diffs, inv, diffs)
                loglik += np.sum(-0.5 * (d * np.log(2 * np.pi) + logdet + quad))
                continue

            Soo = Sigma[np.ix_(obs_idx, obs_idx)] + jitter * np.eye(len(obs_idx))
            Smm = Sigma[np.ix_(mis_idx, mis_idx)]
            Smo = Sigma[np.ix_(mis_idx, obs_idx)]
            Soo_inv = np.linalg.inv(Soo)
            cond_cov = Smm - Smo @ Soo_inv @ Smo.T  # covarianza condicional de las faltantes

            if len(obs_idx) > 0:
                Xo = X[np.ix_(rows, obs_idx)]
                dev = Xo - mu[obs_idx]
                cond_mean = mu[mis_idx] + dev @ Soo_inv.T @ Smo.T
                # log-verosimilitud marginal de la parte OBSERVADA (lo único identificable)
                sign, logdet = np.linalg.slogdet(Soo)
                inv_dev = dev @ Soo_inv
                quad = np.einsum('ij,ij->i', inv_dev, dev)
                loglik += np.sum(-0.5 * (len(obs_idx) * np.log(2 * np.pi) + logdet + quad))
            else:
                cond_mean = np.tile(mu[mis_idx], (len(rows), 1))

            X_filled[np.ix_(rows, mis_idx)] = cond_mean
            # término de corrección: covarianza condicional se suma len(rows) veces
            C_block = np.zeros((d, d))
            C_block[np.ix_(mis_idx, mis_idx)] = cond_cov * len(rows)
            C_sum += C_block

        loglik_history.append(loglik)

        mu_new = X_filled.mean(axis=0)
        dev_full = X_filled - mu_new
        Sigma_new = (dev_full.T @ dev_full + C_sum) / n
        Sigma_new = (Sigma_new + Sigma_new.T) / 2  # simetrizar por estabilidad numérica

        shift = np.linalg.norm(mu_new - mu) + np.linalg.norm(Sigma_new - Sigma)
        mu, Sigma = mu_new, Sigma_new
        if verbose:
            print(f"iter {it:3d}  loglik={loglik:.2f}  shift={shift:.2e}")
        if shift < tol:
            break

    return mu, Sigma, loglik_history


if __name__ == "__main__":
    from preprocess import run

    df, calib, evaluation, holdout = run(save=False)
    sensors = ["PT08.S1(CO)", "PT08.S2(NMHC)", "PT08.S3(NOx)", "PT08.S4(NO2)", "PT08.S5(O3)"]
    X = calib[sensors].values

    n_missing = np.isnan(X).any(axis=1).sum()
    print(f"Filas con al menos un faltante: {n_missing} de {len(X)} ({100*n_missing/len(X):.1f}%)")

    mu, Sigma, hist = em_missing_gaussian(X, verbose=False)
    print("\nmu estimado (EM, con faltantes):")
    for name, val in zip(sensors, mu):
        print(f"  {name:16s} {val:9.2f}")

    # comparación contra casos completos (baseline ingenuo)
    complete = X[~np.isnan(X).any(axis=1)]
    mu_cc = complete.mean(axis=0)
    print("\nmu (solo casos completos, baseline):")
    for name, val in zip(sensors, mu_cc):
        print(f"  {name:16s} {val:9.2f}")

    print(f"\nLog-verosimilitud: inicial={hist[0]:.1f} -> final={hist[-1]:.1f} en {len(hist)} iteraciones")
    print(f"Diferencia absoluta media |mu_EM - mu_casosCompletos|: {np.mean(np.abs(mu - mu_cc)):.3f}")
