"""
Paso 1 de la ruta computacional (Problema 1: sensores de calidad del aire).
Preparación temporal:
 - parsear fecha/hora
 - reemplazar el código de faltante (-200) por NaN
 - ordenar cronológicamente
 - partición cronológica (NO aleatoria) entre calibración inicial y evaluación
"""
import pandas as pd
import numpy as np
from pathlib import Path

RAW_PATH = Path(__file__).resolve().parents[1] / "data_raw" / "AirQualityUCI.csv"
PROCESSED_DIR = Path(__file__).resolve().parents[1] / "data_processed"


def load_raw(path: Path = RAW_PATH) -> pd.DataFrame:
    """Carga el archivo original del UCI Air Quality dataset.
    El archivo usa ';' como separador y ',' como separador decimal,
    y trae columnas vacías finales por el formato original."""
    df = pd.read_csv(path, sep=";", decimal=",")
    # eliminar columnas completamente vacías (artefacto del CSV original)
    df = df.dropna(axis=1, how="all")
    df = df.loc[:, ~df.columns.str.match(r"^Unnamed")]
    return df


def build_datetime_index(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    # Time viene como HH.MM.SS -> normalizar a HH:MM:SS
    time_fixed = df["Time"].astype(str).str.replace(".", ":", regex=False)
    dt = pd.to_datetime(
        df["Date"].astype(str) + " " + time_fixed,
        format="%d/%m/%Y %H:%M:%S",
        errors="coerce",
    )
    df["datetime"] = dt
    df = df.drop(columns=["Date", "Time"])
    df = df.dropna(subset=["datetime"])
    df = df.sort_values("datetime").reset_index(drop=True)
    return df


def replace_missing_code(df: pd.DataFrame, code: float = -200.0) -> pd.DataFrame:
    df = df.copy()
    numeric_cols = df.columns.drop("datetime")
    df[numeric_cols] = df[numeric_cols].replace(code, np.nan)
    return df


def chronological_split(df: pd.DataFrame, calib_frac: float = 0.5, eval_frac: float = 0.35):
    """Partición cronológica en tres bloques:
    - calibración inicial (ajuste de g(s_t) e inicialización bayesiana mu0, sigma0^2)
    - evaluación (actualización en línea, alertas, deriva)
    - reserva final (opcional, para pruebas adicionales / deriva artificial)
    """
    n = len(df)
    n_calib = int(n * calib_frac)
    n_eval = int(n * eval_frac)
    calib = df.iloc[:n_calib].reset_index(drop=True)
    evaluation = df.iloc[n_calib:n_calib + n_eval].reset_index(drop=True)
    holdout = df.iloc[n_calib + n_eval:].reset_index(drop=True)
    return calib, evaluation, holdout


def run(save: bool = True):
    df = load_raw()
    df = build_datetime_index(df)
    df = replace_missing_code(df)

    calib, evaluation, holdout = chronological_split(df)

    if save:
        PROCESSED_DIR.mkdir(exist_ok=True)
        df.to_csv(PROCESSED_DIR / "air_quality_clean.csv", index=False)
        calib.to_csv(PROCESSED_DIR / "calib.csv", index=False)
        evaluation.to_csv(PROCESSED_DIR / "eval.csv", index=False)
        holdout.to_csv(PROCESSED_DIR / "holdout.csv", index=False)

    return df, calib, evaluation, holdout


if __name__ == "__main__":
    df, calib, evaluation, holdout = run()
    print(f"Total registros: {len(df)}")
    print(f"Calibración: {len(calib)}  Evaluación: {len(evaluation)}  Reserva: {len(holdout)}")
    print(f"Rango temporal: {df['datetime'].min()} -> {df['datetime'].max()}")
    print("\nProporción de faltantes por columna (dataset completo):")
    print((df.isna().mean().sort_values(ascending=False) * 100).round(1))
