"""
Pasos 3 y 4 de la ruta computacional: modelo normal-normal para el error
del sensor y actualización bayesiana recursiva.

  e_t | mu ~ N(mu, sigma^2)          (sigma^2: varianza de ruido, conocida/estimada)
  mu   ~ N(mu0, sigma0^2)            (prior)

Tras n observaciones:
  sigma_n^2 = ( 1/sigma0^2 + n/sigma^2 )^-1
  mu_n      = sigma_n^2 * ( mu0/sigma0^2 + (1/sigma^2) * sum(e_i) )

Predictiva para la siguiente observación:
  e_{n+1} | D_n ~ N( mu_n , sigma^2 + sigma_n^2 )

Todo se implementa de forma recursiva (O(1) por observación), sin
almacenar el historial completo: basta con guardar n y la suma acumulada.
"""
import numpy as np
from dataclasses import dataclass, field
from scipy import stats


@dataclass
class BayesState:
    mu0: float
    sigma0_sq: float
    sigma_sq: float  # varianza de ruido (observación), asumida conocida
    n: float = 0.0
    sum_e: float = 0.0
    forgetting: float = 1.0  # rho en (0,1]; 1.0 = memoria infinita (Bayes recursivo puro)

    @property
    def mu_n(self) -> float:
        if self.n == 0:
            return self.mu0
        precision = 1.0 / self.sigma0_sq + self.n / self.sigma_sq
        return (self.mu0 / self.sigma0_sq + self.sum_e / self.sigma_sq) / precision

    @property
    def sigma_n_sq(self) -> float:
        precision = 1.0 / self.sigma0_sq + self.n / self.sigma_sq
        return 1.0 / precision

    def predictive_params(self):
        """Media y varianza de la predictiva de la SIGUIENTE observación."""
        return self.mu_n, self.sigma_sq + self.sigma_n_sq

    def update(self, e_t: float):
        """Actualización recursiva de las estadísticas suficientes (n, sum_e).

        Con forgetting < 1 se aplica un descuento exponencial al estado
        acumulado ANTES de incorporar la nueva observación. Esto evita que
        sigma_n^2 colapse a un valor arbitrariamente pequeño con memoria
        infinita (lo que en un entorno con deriva real vuelve al detector
        insensible a cambios recientes y, paradójicamente, hipersensible a
        ruido normal una vez que sigma_n^2 es minúsculo). El tamaño de
        muestra efectivo en estado estacionario es aproximadamente
        1 / (1 - forgetting)."""
        self.n = self.forgetting * self.n + 1
        self.sum_e = self.forgetting * self.sum_e + e_t


def initialize_from_calibration(e_calib: np.ndarray, sigma0_inflation: float = 4.0,
                                 forgetting: float = 1.0) -> BayesState:
    """Inicialización bayesiana (paso 3): mu0, sigma0^2 a partir del
    periodo de calibración. sigma0_inflation infla la incertidumbre del
    prior respecto de la varianza muestral, para reflejar que el periodo
    de calibración no garantiza estabilidad futura."""
    e = e_calib[~np.isnan(e_calib)]
    mu0 = float(np.mean(e))
    sigma_sq = float(np.var(e, ddof=1))          # varianza de ruido "conocida"
    sigma0_sq = sigma_sq * sigma0_inflation       # incertidumbre inicial sobre mu
    return BayesState(mu0=mu0, sigma0_sq=sigma0_sq, sigma_sq=sigma_sq, forgetting=forgetting)


def run_online(e_series: np.ndarray, state: BayesState):
    """Recorre la secuencia de errores, actualizando el estado bayesiano
    ANTES de calcular la predictiva de cada punto (evaluación out-of-sample
    tipo 'one-step-ahead'). Devuelve trayectorias de mu_n, sigma_n^2,
    y la log-densidad predictiva de cada observación (NaN si faltante)."""
    mu_traj, sigma_traj, logpred = [], [], []
    for e_t in e_series:
        pred_mu, pred_var = state.predictive_params()
        if np.isnan(e_t):
            logpred.append(np.nan)
        else:
            logpred.append(float(stats.norm.logpdf(e_t, loc=pred_mu, scale=np.sqrt(pred_var))))
            state.update(e_t)
        mu_traj.append(state.mu_n)
        sigma_traj.append(state.sigma_n_sq)
    return np.array(mu_traj), np.array(sigma_traj), np.array(logpred)


if __name__ == "__main__":
    from preprocess import run
    from calibration import fit_calibration, residuals

    _, calib, evaluation, holdout = run(save=False)
    model = fit_calibration(calib)
    e_calib = residuals(calib, model).values
    e_eval = residuals(evaluation, model).values

    state = initialize_from_calibration(e_calib)
    print(f"Prior: mu0={state.mu0:.4f}, sigma0^2={state.sigma0_sq:.4f}, sigma^2={state.sigma_sq:.4f}")

    mu_traj, sigma_traj, logpred = run_online(e_eval, state)
    print(f"mu_n final: {mu_traj[-1]:.4f}  (vs. mu0={state.mu0:.4f})")
    print(f"sigma_n^2 final: {sigma_traj[-1]:.6f}")
    print(f"Log-densidad predictiva promedio: {np.nanmean(logpred):.4f}")
