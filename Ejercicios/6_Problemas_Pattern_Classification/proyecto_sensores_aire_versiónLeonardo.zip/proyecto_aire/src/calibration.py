"""
Paso 2 de la ruta computacional: modelo base g(s_t).
Usamos como caso de estudio:
  y_t = CO(GT)        -> medición de referencia (analizador certificado)
  s_t = PT08.S1(CO)   -> respuesta del sensor químico de bajo costo

g(s_t) es una calibración nominal simple (regresión lineal), ajustada
SOLO con el bloque de calibración. Los residuos e_t = y_t - g(s_t) son
el objeto de estudio del modelo bayesiano normal-normal.
"""
import numpy as np
import pandas as pd
from dataclasses import dataclass

TARGET = "CO(GT)"
SENSOR = "PT08.S1(CO)"


@dataclass
class LinearCalibration:
    slope: float
    intercept: float

    def predict(self, s):
        return self.intercept + self.slope * np.asarray(s)


def fit_calibration(calib_df: pd.DataFrame, target: str = TARGET, sensor: str = SENSOR) -> LinearCalibration:
    """MLE de una regresión lineal simple g(s) = a + b*s usando mínimos cuadrados
    (equivalente al MLE gaussiano de y | s bajo ruido normal)."""
    sub = calib_df[[target, sensor]].dropna()
    s = sub[sensor].values
    y = sub[target].values
    b, a = np.polyfit(s, y, deg=1)  # y = a + b*s
    return LinearCalibration(slope=b, intercept=a)


def residuals(df: pd.DataFrame, model: LinearCalibration, target: str = TARGET, sensor: str = SENSOR) -> pd.Series:
    """Calcula e_t = y_t - g(s_t). Devuelve NaN donde falte y_t o s_t
    (dato faltante real del instrumento, no se imputa aquí)."""
    pred = model.predict(df[sensor])
    e = df[target].values - pred
    return pd.Series(e, index=df.index, name="residual")


if __name__ == "__main__":
    from preprocess import run

    _, calib, evaluation, holdout = run(save=False)
    model = fit_calibration(calib)
    print(f"g(s) = {model.intercept:.4f} + {model.slope:.6f} * s")

    e_calib = residuals(calib, model)
    e_eval = residuals(evaluation, model)
    print(f"\nResiduos de calibración: n={e_calib.notna().sum()}, "
          f"media={e_calib.mean():.4f}, sd={e_calib.std():.4f}")
    print(f"Residuos de evaluación:  n={e_eval.notna().sum()}, "
          f"media={e_eval.mean():.4f}, sd={e_eval.std():.4f}")
