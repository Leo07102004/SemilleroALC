"""
Paso 5: alerta probabilística -> marcar observaciones con densidad
predictiva muy baja (posible anomalía puntual, no necesariamente deriva).

Paso 6: detección de deriva -> se analiza una VENTANA de mu_n (o de la
log-predictiva) para evitar declarar deriva a partir de un solo dato
extremo. Se usa una regla simple y transparente: la deriva se declara
cuando la media móvil de mu_n se aleja de mu0 en más de k desviaciones
posteriores de forma sostenida durante 'persistence' pasos consecutivos.
"""
import numpy as np
import pandas as pd


def flag_point_alerts(logpred: np.ndarray, quantile: float = 0.01) -> np.ndarray:
    """Marca como alerta puntual las observaciones cuya log-densidad
    predictiva está en el quantile inferior (p.ej. 1%) de la distribución
    empírica de log-densidades observadas."""
    valid = logpred[~np.isnan(logpred)]
    threshold = np.quantile(valid, quantile)
    flags = logpred < threshold
    flags = np.where(np.isnan(logpred), False, flags)
    return flags, threshold


def detect_drift(mu_traj: np.ndarray, mu0: float, sigma_traj: np.ndarray,
                  window: int = 50, k: float = 3.0, persistence: int = 30):
    """Detección de deriva persistente sobre la trayectoria de mu_n.

    - Se calcula una media móvil de mu_n con ventana 'window'.
    - Se compara contra mu0 usando una banda ADAPTATIVA k*sqrt(sigma_n^2):
      la incertidumbre posterior actual, que se va estrechando a medida
      que llegan más observaciones. Esto permite detectar desplazamientos
      pequeños pero sostenidos, en vez de exigir siempre la misma holgura
      amplia del prior inicial.
    - Se declara deriva en el primer instante en que la condición se
      mantiene de forma continua durante 'persistence' pasos.

    Devuelve: (indice_deteccion o None, serie_booleana_fuera_de_banda, media_movil)
    """
    s = pd.Series(mu_traj)
    rolling = s.rolling(window, min_periods=window // 2).mean()
    band = k * np.sqrt(np.asarray(sigma_traj))
    out_of_band = (rolling - mu0).abs().values > band

    # buscar la primera racha sostenida de longitud >= persistence
    detection_idx = None
    run_len = 0
    out_of_band_filled = np.where(np.isnan(rolling.values), False, out_of_band)
    for i, flag in enumerate(out_of_band_filled):
        run_len = run_len + 1 if flag else 0
        if run_len >= persistence:
            detection_idx = i - persistence + 1
            break

    return detection_idx, out_of_band, rolling


def inject_synthetic_drift(e_series: np.ndarray, start_frac: float = 0.5,
                            magnitude: float = 1.5) -> np.ndarray:
    """Inyecta una deriva aditiva conocida (escalón) a partir de start_frac
    de la secuencia, para poder medir el TIEMPO DE DETECCIÓN de forma
    controlada (sección 2.5 del documento base)."""
    e = e_series.copy()
    n = len(e)
    start = int(n * start_frac)
    e[start:] = e[start:] + magnitude
    return e, start


if __name__ == "__main__":
    from preprocess import run
    from calibration import fit_calibration, residuals
    from bayes_recursive import initialize_from_calibration, run_online

    _, calib, evaluation, holdout = run(save=False)
    model = fit_calibration(calib)
    e_calib = residuals(calib, model).values
    e_eval = residuals(evaluation, model).values

    FORGETTING = 0.995  # tamaño de muestra efectivo ~ 200 observaciones

    # --- alertas puntuales sobre la secuencia real de evaluación ---
    state = initialize_from_calibration(e_calib, forgetting=FORGETTING)
    mu_traj, sigma_traj, logpred = run_online(e_eval, state)
    flags, thr = flag_point_alerts(logpred)
    print(f"Umbral de alerta (log-densidad, cuantil 1%): {thr:.3f}")
    print(f"Número de alertas puntuales: {flags.sum()} de {np.sum(~np.isnan(logpred))} observaciones válidas")

    # --- deriva real (si existe) ---
    idx, out_band, rolling = detect_drift(mu_traj, state.mu0, sigma_traj)
    print(f"Detección de deriva (datos reales) en índice: {idx}")

    # --- deriva artificial inyectada, para medir tiempo de detección ---
    e_synth, start = inject_synthetic_drift(e_eval, start_frac=0.5, magnitude=1.5)
    state2 = initialize_from_calibration(e_calib, forgetting=FORGETTING)
    mu_traj2, sigma_traj2, logpred2 = run_online(e_synth, state2)
    idx2, out_band2, rolling2 = detect_drift(mu_traj2, state2.mu0, sigma_traj2)
    if idx2 is not None:
        delay = idx2 - start
        print(f"Deriva artificial inyectada en índice {start}; detectada en índice {idx2} "
              f"(retraso = {delay} observaciones = {delay} horas aprox.)")
    else:
        print("Deriva artificial NO detectada con los parámetros actuales.")
