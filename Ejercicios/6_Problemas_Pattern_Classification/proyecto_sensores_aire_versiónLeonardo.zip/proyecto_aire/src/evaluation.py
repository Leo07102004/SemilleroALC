"""
Sección 2.5 del documento base: evaluación y productos del Problema 1.

Implementa:
 - Error de calibración antes (sin corrección de sesgo) y después
   (con corrección bayesiana online) de la actualización.
 - Cobertura empírica de intervalos predictivos del 90% y 95%.
 - Tiempo de detección de una deriva artificial (Monte Carlo, sobre datos
   simulados estacionarios para tener un experimento controlado y limpio).
 - Tasa de falsas alarmas del detector de deriva sobre datos SIN deriva.
 - Comparación MLE vs. Bayes en régimen de muestra pequeña.
"""
import numpy as np
from scipy import stats

from bayes_recursive import BayesState, initialize_from_calibration, run_online
from alerts_drift import detect_drift, inject_synthetic_drift


def calibration_error(e_series: np.ndarray, mu_traj: np.ndarray):
    """Compara el error ABSOLUTO medio de predecir e_t=0 (sin corrección,
    "antes") contra usar la media posterior mu_{n-1} como predicción
    puntual del siguiente error ("después", con corrección online)."""
    valid = ~np.isnan(e_series)
    e = e_series[valid]
    # mu_{t-1}: predicción ANTES de observar e_t (usar el valor previo de la trayectoria)
    mu_prev = np.concatenate(([mu_traj[0]], mu_traj[:-1]))[valid]

    mae_before = np.mean(np.abs(e))            # sin corrección de sesgo
    mae_after = np.mean(np.abs(e - mu_prev))    # con corrección bayesiana online
    rmse_before = np.sqrt(np.mean(e ** 2))
    rmse_after = np.sqrt(np.mean((e - mu_prev) ** 2))
    return dict(mae_before=mae_before, mae_after=mae_after,
                rmse_before=rmse_before, rmse_after=rmse_after)


def predictive_coverage(e_calib: np.ndarray, e_eval: np.ndarray, forgetting: float = 0.995,
                         levels=(0.90, 0.95)):
    """Recorre la secuencia de evaluación y, para cada observación válida,
    verifica si cae dentro del intervalo predictivo de nivel dado,
    calculado ANTES de observar el dato (evaluación one-step-ahead honesta)."""
    state = initialize_from_calibration(e_calib, forgetting=forgetting)
    coverage_hits = {lv: [] for lv in levels}
    for e_t in e_eval:
        pred_mu, pred_var = state.predictive_params()
        pred_sd = np.sqrt(pred_var)
        if not np.isnan(e_t):
            for lv in levels:
                z = stats.norm.ppf(0.5 + lv / 2)
                lo, hi = pred_mu - z * pred_sd, pred_mu + z * pred_sd
                coverage_hits[lv].append(lo <= e_t <= hi)
            state.update(e_t)
    return {lv: float(np.mean(hits)) for lv, hits in coverage_hits.items()}


def monte_carlo_drift_detection(e_calib: np.ndarray, n_eval: int = 2000, n_reps: int = 100,
                                 drift_magnitude: float = 1.0, drift_start_frac: float = 0.5,
                                 forgetting: float = 0.995, seed: int = 0):
    """Experimento controlado y limpio:
    simula secuencias ESTACIONARIAS N(mu0, sigma^2) (mismos parámetros
    que el periodo de calibración), inyecta una deriva aditiva conocida
    a partir de drift_start_frac, y mide:
      - tiempo de detección (en observaciones, respecto del inicio real de la deriva)
      - tasa de falsas alarmas: proporción de réplicas SIN deriva en las que
        el detector dispara de todas formas.
    """
    rng = np.random.default_rng(seed)
    e = e_calib[~np.isnan(e_calib)]
    mu0, sigma = float(np.mean(e)), float(np.std(e, ddof=1))

    delays = []
    false_alarms = 0
    for rep in range(n_reps):
        clean = rng.normal(mu0, sigma, size=n_eval)
        drifted, start = inject_synthetic_drift(clean, start_frac=drift_start_frac,
                                                  magnitude=drift_magnitude)

        state = initialize_from_calibration(e, forgetting=forgetting)
        mu_traj, sigma_traj, _ = run_online(drifted, state)
        idx, _, _ = detect_drift(mu_traj, state.mu0, sigma_traj)
        if idx is not None and idx >= start:
            delays.append(idx - start)

        # réplica de control SIN deriva, para tasa de falsas alarmas
        state_fa = initialize_from_calibration(e, forgetting=forgetting)
        mu_traj_fa, sigma_traj_fa, _ = run_online(clean, state_fa)
        idx_fa, _, _ = detect_drift(mu_traj_fa, state_fa.mu0, sigma_traj_fa)
        if idx_fa is not None:
            false_alarms += 1

    result = dict(
        n_reps=n_reps,
        detection_rate=len(delays) / n_reps,
        mean_delay=float(np.mean(delays)) if delays else None,
        median_delay=float(np.median(delays)) if delays else None,
        false_alarm_rate=false_alarms / n_reps,
    )
    return result


def mle_vs_bayes_small_sample(e_calib: np.ndarray, sample_sizes=(3, 5, 10, 20, 50), forgetting: float = 1.0,
                               n_reps: int = 200, seed: int = 1):
    """Compara la estabilidad del estimador MLE (media muestral) contra la
    media posterior bayesiana cuando el tamaño de muestra es pequeño.
    Se simulan repetidamente sub-muestras de la distribución de calibración
    y se mide el error cuadrático medio de cada estimador respecto de la
    media poblacional (aproximada con todo el bloque de calibración)."""
    rng = np.random.default_rng(seed)
    e = e_calib[~np.isnan(e_calib)]
    mu0, sigma = float(np.mean(e)), float(np.std(e, ddof=1))
    true_mu = mu0  # referencia poblacional aproximada

    results = {}
    for n in sample_sizes:
        mle_errs, bayes_errs = [], []
        for _ in range(n_reps):
            sample = rng.normal(true_mu, sigma, size=n)
            mle = np.mean(sample)
            state = BayesState(mu0=0.0, sigma0_sq=sigma ** 2, sigma_sq=sigma ** 2, forgetting=forgetting)
            for x in sample:
                state.update(x)
            bayes = state.mu_n
            mle_errs.append((mle - true_mu) ** 2)
            bayes_errs.append((bayes - true_mu) ** 2)
        results[n] = dict(mse_mle=float(np.mean(mle_errs)), mse_bayes=float(np.mean(bayes_errs)))
    return results


if __name__ == "__main__":
    from preprocess import run
    from calibration import fit_calibration, residuals

    _, calib, evaluation, holdout = run(save=False)
    model = fit_calibration(calib)
    e_calib = residuals(calib, model).values
    e_eval = residuals(evaluation, model).values

    state = initialize_from_calibration(e_calib, forgetting=0.995)
    mu_traj, _, _ = run_online(e_eval.copy(), state)

    print("== Error de calibración (antes vs. después) ==")
    print(calibration_error(e_eval, mu_traj))

    print("\n== Cobertura empírica de intervalos predictivos ==")
    print(predictive_coverage(e_calib, e_eval))

    print("\n== Monte Carlo: detección de deriva artificial (datos simulados limpios) ==")
    print(monte_carlo_drift_detection(e_calib, n_reps=50))

    print("\n== MLE vs. Bayes en muestra pequeña ==")
    for n, r in mle_vs_bayes_small_sample(e_calib).items():
        print(f"  n={n:3d}  MSE(MLE)={r['mse_mle']:.4f}  MSE(Bayes)={r['mse_bayes']:.4f}")
