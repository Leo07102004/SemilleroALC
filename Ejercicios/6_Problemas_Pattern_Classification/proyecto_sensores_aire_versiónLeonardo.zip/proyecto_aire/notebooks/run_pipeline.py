"""
Script maestro del Problema 1 (sensores de calidad del aire).
Ejecuta la arquitectura completa (sección 8 del documento base):
  1. Datos y metadatos           -> preprocess.py
  2. Preprocesamiento            -> preprocess.py (partición cronológica)
  3. Modelo probabilístico       -> calibration.py + bayes_recursive.py
  4. Inferencia / optimización   -> bayes_recursive.py (recursivo) + em_multivariate.py
  5. Validación fuera de muestra -> evaluation.py
  6. Incertidumbre e interpretación -> figuras y tablas en results/

Genera en results/:
  - fig_mu_posterior.png   : trayectoria de mu_n con banda posterior
  - fig_alerts.png         : log-densidad predictiva y alertas puntuales
  - fig_drift_mc.png       : ejemplo de detección de deriva (Monte Carlo)
  - tabla_metricas.csv     : resumen numérico de todas las métricas
  - reporte.txt            : resumen textual de resultados
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pathlib import Path

from preprocess import run as run_preprocess
from calibration import fit_calibration, residuals
from bayes_recursive import initialize_from_calibration, run_online
from alerts_drift import flag_point_alerts, detect_drift, inject_synthetic_drift
from evaluation import (calibration_error, predictive_coverage,
                         monte_carlo_drift_detection, mle_vs_bayes_small_sample)
from em_multivariate import em_missing_gaussian

RESULTS_DIR = Path(__file__).resolve().parents[1] / "results"
FORGETTING = 0.995


def main():
    RESULTS_DIR.mkdir(exist_ok=True)
    report_lines = []

    def log(msg=""):
        print(msg)
        report_lines.append(str(msg))

    log("=" * 70)
    log("PROBLEMA 1: monitoreo y recalibración de sensores de calidad del aire")
    log("=" * 70)

    # --- 1-2. datos y preprocesamiento ---
    df, calib, evaluation, holdout = run_preprocess(save=True)
    log(f"\nRegistros totales: {len(df)}  (rango {df['datetime'].min()} a {df['datetime'].max()})")
    log(f"Calibración: {len(calib)}  Evaluación: {len(evaluation)}  Reserva: {len(holdout)}")

    # --- 3. modelo base g(s_t) y residuos ---
    model = fit_calibration(calib)
    log(f"\nCalibración nominal g(s) = {model.intercept:.4f} + {model.slope:.6f} * s")
    e_calib = residuals(calib, model).values
    e_eval = residuals(evaluation, model).values
    log(f"Residuos calibración: n={np.sum(~np.isnan(e_calib))}, media={np.nanmean(e_calib):.4f}, sd={np.nanstd(e_calib):.4f}")
    log(f"Residuos evaluación:  n={np.sum(~np.isnan(e_eval))}, media={np.nanmean(e_eval):.4f}, sd={np.nanstd(e_eval):.4f}")

    # --- 4. inicialización + actualización bayesiana recursiva ---
    state = initialize_from_calibration(e_calib, forgetting=FORGETTING)
    log(f"\nPrior: mu0={state.mu0:.4f}, sigma0^2={state.sigma0_sq:.4f}, sigma^2(ruido)={state.sigma_sq:.4f}")
    log(f"Factor de olvido (Bayes recursivo con descuento): rho={FORGETTING} "
        f"(n_efectivo en estado estacionario ~ {1/(1-FORGETTING):.0f})")

    mu_traj, sigma_traj, logpred = run_online(e_eval.copy(), state)
    log(f"mu_n final: {mu_traj[-1]:.4f}   sigma_n^2 final: {sigma_traj[-1]:.6f}")

    # --- 5. alertas puntuales ---
    flags, thr = flag_point_alerts(logpred)
    log(f"\nAlertas puntuales (log-densidad < percentil 1%): {int(flags.sum())} de "
        f"{int(np.sum(~np.isnan(logpred)))} observaciones válidas ({100*flags.sum()/np.sum(~np.isnan(logpred)):.2f}%)")

    # --- 6. detección de deriva sobre los datos reales ---
    idx_real, out_band, rolling = detect_drift(mu_traj, state.mu0, sigma_traj)
    log(f"Deriva detectada en datos reales en el índice: {idx_real} "
        f"(~{idx_real} horas tras iniciar la evaluación)" if idx_real is not None else
        "No se detectó deriva sostenida en los datos reales de evaluación.")

    # --- 7. EM multivariante con datos faltantes ---
    sensors = ["PT08.S1(CO)", "PT08.S2(NMHC)", "PT08.S3(NOx)", "PT08.S4(NO2)", "PT08.S5(O3)"]
    X = calib[sensors].values
    n_missing = int(np.isnan(X).any(axis=1).sum())
    mu_em, Sigma_em, hist = em_missing_gaussian(X)
    complete = X[~np.isnan(X).any(axis=1)]
    mu_cc = complete.mean(axis=0)
    log(f"\nEM multivariante (5 sensores): {n_missing}/{len(X)} filas con algún faltante "
        f"({100*n_missing/len(X):.1f}%)")
    log(f"Log-verosimilitud EM: {hist[0]:.1f} -> {hist[-1]:.1f} en {len(hist)} iteraciones")
    log(f"Diferencia media |mu_EM - mu_casos_completos|: {np.mean(np.abs(mu_em - mu_cc)):.4f}")

    # --- 5 (bis). validación fuera de muestra: métricas de la sección 2.5 ---
    cal_err = calibration_error(e_eval, mu_traj)
    coverage = predictive_coverage(e_calib, e_eval, forgetting=FORGETTING)
    mc = monte_carlo_drift_detection(e_calib, n_reps=100, forgetting=FORGETTING)
    mle_bayes = mle_vs_bayes_small_sample(e_calib)

    log("\n--- Error de calibración (antes/después de corrección bayesiana online) ---")
    log(f"MAE  antes={cal_err['mae_before']:.4f}   después={cal_err['mae_after']:.4f}")
    log(f"RMSE antes={cal_err['rmse_before']:.4f}   después={cal_err['rmse_after']:.4f}")

    log("\n--- Cobertura empírica de intervalos predictivos (one-step-ahead) ---")
    for lv, cov in coverage.items():
        log(f"Nivel nominal {int(lv*100)}%  ->  cobertura empírica {cov*100:.1f}%")

    log("\n--- Monte Carlo: detección de deriva artificial (100 réplicas, datos simulados limpios) ---")
    log(f"Tasa de detección: {mc['detection_rate']*100:.0f}%")
    log(f"Retraso medio: {mc['mean_delay']:.1f} observaciones (~horas)")
    log(f"Retraso mediano: {mc['median_delay']:.1f} observaciones")
    log(f"Tasa de falsas alarmas (sin deriva): {mc['false_alarm_rate']*100:.1f}%")

    log("\n--- MLE vs. Bayes en régimen de muestra pequeña (MSE respecto de mu poblacional) ---")
    for n, r in mle_bayes.items():
        log(f"  n={n:3d}   MSE(MLE)={r['mse_mle']:.4f}   MSE(Bayes)={r['mse_bayes']:.4f}")

    # ===================== FIGURAS =====================

    # Fig 1: trayectoria de mu_n con banda posterior +/- 2 sigma_n
    fig, ax = plt.subplots(figsize=(10, 4.5))
    sd_traj = np.sqrt(sigma_traj)
    ax.plot(mu_traj, color="#1f77b4", label=r"$\mu_n$ (media posterior)")
    ax.fill_between(range(len(mu_traj)), mu_traj - 2 * sd_traj, mu_traj + 2 * sd_traj,
                     color="#1f77b4", alpha=0.2, label=r"banda $\pm 2\sigma_n$")
    ax.axhline(state.mu0, color="gray", linestyle="--", label=r"$\mu_0$ (prior)")
    if idx_real is not None:
        ax.axvline(idx_real, color="red", linestyle=":", label="deriva detectada")
    ax.set_xlabel("Observación (índice temporal en el periodo de evaluación)")
    ax.set_ylabel(r"$\mu_n$ (sesgo estimado del sensor)")
    ax.set_title("Actualización bayesiana recursiva del sesgo del sensor")
    ax.legend(loc="best", fontsize=8)
    fig.tight_layout()
    fig.savefig(RESULTS_DIR / "fig_mu_posterior.png", dpi=150)
    plt.close(fig)

    # Fig 2: log-densidad predictiva y alertas puntuales
    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(logpred, color="#555555", linewidth=0.8, label="log-densidad predictiva")
    idx_alerts = np.where(flags)[0]
    ax.scatter(idx_alerts, logpred[idx_alerts], color="red", s=15, zorder=5, label="alerta puntual")
    ax.axhline(thr, color="red", linestyle="--", linewidth=0.8, label="umbral (percentil 1%)")
    ax.set_xlabel("Observación")
    ax.set_ylabel("log p(e_t | D_{t-1})")
    ax.set_title("Alertas probabilísticas por baja densidad predictiva")
    ax.legend(loc="lower left", fontsize=8)
    fig.tight_layout()
    fig.savefig(RESULTS_DIR / "fig_alerts.png", dpi=150)
    plt.close(fig)

    # Fig 3: ejemplo ilustrativo de detección de deriva artificial (datos simulados limpios)
    e_clean = np.random.default_rng(42).normal(state.mu0, np.sqrt(state.sigma_sq), size=2000)
    e_drifted, start = inject_synthetic_drift(e_clean, start_frac=0.5, magnitude=1.0)
    state_demo = initialize_from_calibration(e_calib, forgetting=FORGETTING)
    mu_demo, sigma_demo, _ = run_online(e_drifted, state_demo)
    idx_demo, _, rolling_demo = detect_drift(mu_demo, state_demo.mu0, sigma_demo)

    fig, ax = plt.subplots(figsize=(10, 4.5))
    ax.plot(mu_demo, color="#2ca02c", label=r"$\mu_n$ (datos simulados con deriva conocida)")
    ax.plot(rolling_demo.values, color="#ff7f0e", linestyle="--", label="media móvil")
    ax.axvline(start, color="black", linestyle=":", label="inicio real de la deriva")
    if idx_demo is not None:
        ax.axvline(idx_demo, color="red", linestyle=":", label="deriva detectada")
    ax.set_xlabel("Observación simulada")
    ax.set_ylabel(r"$\mu_n$")
    ax.set_title("Ejemplo controlado: detección de una deriva artificial inyectada")
    ax.legend(loc="best", fontsize=8)
    fig.tight_layout()
    fig.savefig(RESULTS_DIR / "fig_drift_mc.png", dpi=150)
    plt.close(fig)

    # ===================== TABLAS =====================
    rows = [
        ("MAE antes de corrección bayesiana", cal_err["mae_before"]),
        ("MAE después de corrección bayesiana", cal_err["mae_after"]),
        ("RMSE antes de corrección bayesiana", cal_err["rmse_before"]),
        ("RMSE después de corrección bayesiana", cal_err["rmse_after"]),
        ("Cobertura empírica (nominal 90%)", coverage[0.90]),
        ("Cobertura empírica (nominal 95%)", coverage[0.95]),
        ("Tasa de detección de deriva (Monte Carlo)", mc["detection_rate"]),
        ("Retraso medio de detección (obs.)", mc["mean_delay"]),
        ("Tasa de falsas alarmas (Monte Carlo)", mc["false_alarm_rate"]),
        ("Alertas puntuales / observaciones válidas", flags.sum() / np.sum(~np.isnan(logpred))),
        ("Diferencia media |mu_EM - mu_casos_completos|", np.mean(np.abs(mu_em - mu_cc))),
    ]
    tabla = pd.DataFrame(rows, columns=["métrica", "valor"])
    tabla.to_csv(RESULTS_DIR / "tabla_metricas.csv", index=False)

    mle_bayes_df = pd.DataFrame([
        {"n": n, "MSE_MLE": r["mse_mle"], "MSE_Bayes": r["mse_bayes"]}
        for n, r in mle_bayes.items()
    ])
    mle_bayes_df.to_csv(RESULTS_DIR / "tabla_mle_vs_bayes.csv", index=False)

    with open(RESULTS_DIR / "reporte.txt", "w") as f:
        f.write("\n".join(report_lines))

    log(f"\nFiguras y tablas guardadas en: {RESULTS_DIR}")


if __name__ == "__main__":
    main()
