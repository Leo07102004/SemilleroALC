"""
Pruebas unitarias básicas (sección 8.2 del documento base: 'tests/').
Ejecutar con: python3 -m pytest tests/ -v   (o simplemente python3 tests/test_core.py)
"""
import sys
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from bayes_recursive import BayesState, initialize_from_calibration, run_online
from calibration import LinearCalibration, fit_calibration
from em_multivariate import em_missing_gaussian
import pandas as pd


def test_bayes_state_prior_only():
    """Sin observaciones, mu_n debe ser exactamente mu0."""
    state = BayesState(mu0=1.5, sigma0_sq=2.0, sigma_sq=1.0)
    assert abs(state.mu_n - 1.5) < 1e-9
    assert abs(state.sigma_n_sq - 2.0) < 1e-9


def test_bayes_recursive_matches_closed_form():
    """La actualización recursiva debe coincidir con la fórmula cerrada
    de Bayes normal-normal calculada en un solo paso con todos los datos."""
    rng = np.random.default_rng(0)
    data = rng.normal(2.0, 1.0, size=50)
    mu0, sigma0_sq, sigma_sq = 0.0, 5.0, 1.0

    state = BayesState(mu0=mu0, sigma0_sq=sigma0_sq, sigma_sq=sigma_sq)
    for x in data:
        state.update(x)

    n = len(data)
    precision = 1 / sigma0_sq + n / sigma_sq
    mu_n_expected = (mu0 / sigma0_sq + np.sum(data) / sigma_sq) / precision
    sigma_n_sq_expected = 1 / precision

    assert abs(state.mu_n - mu_n_expected) < 1e-8
    assert abs(state.sigma_n_sq - sigma_n_sq_expected) < 1e-8


def test_bayes_converges_to_mle_with_flat_prior():
    """Con un prior muy difuso (sigma0^2 grande), mu_n debe aproximarse
    a la media muestral (MLE)."""
    rng = np.random.default_rng(1)
    data = rng.normal(3.0, 1.0, size=1000)
    state = BayesState(mu0=0.0, sigma0_sq=1e8, sigma_sq=1.0)
    for x in data:
        state.update(x)
    assert abs(state.mu_n - np.mean(data)) < 1e-3


def test_forgetting_bounds_variance():
    """Con factor de olvido < 1, sigma_n^2 no debe colapsar a cero incluso
    con muchísimas observaciones (a diferencia de la memoria infinita)."""
    rng = np.random.default_rng(2)
    data = rng.normal(0.0, 1.0, size=20000)
    state = BayesState(mu0=0.0, sigma0_sq=1.0, sigma_sq=1.0, forgetting=0.99)
    for x in data:
        state.update(x)
    assert state.sigma_n_sq > 1e-4  # se mantiene acotada, no colapsa


def test_linear_calibration_recovers_known_line():
    """Con datos generados por y = 2 + 3*s (+ruido pequeño), la calibración
    ajustada debe recuperar aproximadamente esos coeficientes."""
    rng = np.random.default_rng(3)
    s = rng.uniform(0, 10, size=200)
    y = 2 + 3 * s + rng.normal(0, 0.01, size=200)
    df = pd.DataFrame({"CO(GT)": y, "PT08.S1(CO)": s})
    model = fit_calibration(df, target="CO(GT)", sensor="PT08.S1(CO)")
    assert abs(model.intercept - 2) < 0.05
    assert abs(model.slope - 3) < 0.01


def test_em_matches_complete_case_when_mcar_light():
    """Con muy pocos faltantes MCAR, el EM debe dar una media muy cercana
    a la de los casos completos."""
    rng = np.random.default_rng(4)
    mu_true = np.array([1.0, -2.0, 0.5])
    Sigma_true = np.array([[1.0, 0.3, 0.1], [0.3, 2.0, 0.2], [0.1, 0.2, 1.5]])
    X = rng.multivariate_normal(mu_true, Sigma_true, size=2000)
    mask = rng.random(X.shape) < 0.02  # 2% de faltantes MCAR
    X_missing = X.copy()
    X_missing[mask] = np.nan

    mu_em, Sigma_em, hist = em_missing_gaussian(X_missing)
    assert np.max(np.abs(mu_em - mu_true)) < 0.15
    # la log-verosimilitud no debe decrecer entre iteraciones (monotonía del EM)
    diffs = np.diff(hist)
    assert np.all(diffs > -1e-6)


def run_all():
    tests = [v for k, v in globals().items() if k.startswith("test_")]
    passed = 0
    for t in tests:
        try:
            t()
            print(f"OK   {t.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"FAIL {t.__name__}: {e}")
    print(f"\n{passed}/{len(tests)} pruebas pasaron")


if __name__ == "__main__":
    run_all()
